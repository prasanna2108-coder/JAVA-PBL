# College Student ERP — Complete Unified Academic & Placement Management System

A production-grade, centralized College Student ERP system built with **React, Vite, TypeScript, Tailwind CSS** on the frontend, and **Python FastAPI with SQLAlchemy and SQLite** on the backend.

The platform provides a unified database architecture serving three core user roles—**Student**, **Faculty**, and **Administrator**—along with a dedicated **Placement Cell Engine** and an innovative **Smart Insights Suite** (Attendance Planner, Academic Risk Indicator, and What-If CGPA Simulator).

---

## 1. System Architecture

```
                       COLLEGE STUDENT ERP
                                |
                           LOGIN PAGE
                     (Institutional Gmail)
                                |
                       JWT AUTHENTICATION
                                |
             +------------------+------------------+
             |                  |                  |
             v                  v                  v
        STUDENT UI          FACULTY UI          ADMIN UI
             |                  |                  |
             +------------------+------------------+
                                |
                        SHARED SQLite DB
                                |
       +------------------------+------------------------+
       |                        |                        |
       v                        v                        v
ACADEMICS & MARKS       ATTENDANCE LEDGER       PLACEMENT CELL
       |                        |                        |
       +------------------------+------------------------+
                                |
                                v
                       SMART INSIGHTS ENGINE
         +----------------------+----------------------+
         |                      |                      |
         v                      v                      v
ATTENDANCE PLANNER     ACADEMIC RISK EARLY     WHAT-IF CGPA
   (Consecutive)             WARNING            SIMULATOR
```

---

## 2. Technology Stack

### Frontend
- **Framework**: React 18 with TypeScript & Vite
- **Styling**: Tailwind CSS (Restrained, modern design system with subtle borders and clean typography)
- **Routing**: React Router v6 with JWT-protected route guards
- **Icons**: Lucide React
- **Analytics & Visualizations**: Recharts
- **API Client**: Axios with automatic Bearer token injection and 401 interception

### Backend
- **Framework**: Python 3.10+ FastAPI
- **Database & ORM**: SQLite with SQLAlchemy 2.0
- **Validation**: Pydantic v2
- **Security**: Passlib / Bcrypt password hashing + PyJWT for bearer token signing
- **Auto-Initialization**: Automatic SQLite database creation and comprehensive demo seeding on startup

---

## 3. Project Structure

```
student-erp/
├── backend/
│   ├── main.py                     # FastAPI app, CORS, routes & lifespan auto-seed
│   ├── seed.py                     # Comprehensive realistic demo data generator
│   ├── database/
│   │   ├── connection.py           # SQLAlchemy engine & session provider
│   │   └── __init__.py
│   ├── models/
│   │   ├── all_models.py           # Relational SQLite tables & foreign keys
│   │   └── __init__.py
│   ├── schemas/
│   │   ├── all_schemas.py          # Pydantic request & response models
│   │   └── __init__.py
│   ├── auth/
│   │   ├── security.py             # Bcrypt hashing & JWT token generator
│   │   ├── deps.py                 # Bearer token verification & role checkers
│   │   └── __init__.py
│   ├── services/
│   │   ├── smart_engine.py         # Novelty attendance planner, risk, CGPA math
│   │   ├── eligibility_engine.py   # Corporate drive eligibility rules
│   │   ├── notification_service.py # Live user notifications & announcements
│   │   └── __init__.py
│   ├── routes/
│   │   ├── auth.py                 # Login, session verification, logout
│   │   ├── student.py              # Student portal endpoints
│   │   ├── faculty.py              # Faculty grading & attendance endpoints
│   │   ├── admin.py                # Admin directory, drives & academic setup
│   │   ├── smart.py                # Novelty smart engine endpoints
│   │   ├── notifications.py        # In-app notifications
│   │   └── __init__.py
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── components/             # Header, Sidebar, ProtectedRoute, UIState
│   │   ├── layouts/                # DashboardLayout
│   │   ├── pages/
│   │   │   ├── auth/LoginPage.tsx
│   │   │   ├── student/            # Home, Profile, Academics, Attendance, Leave, etc.
│   │   │   ├── faculty/            # Dashboard, Marks, Attendance, Leaves, Analytics
│   │   │   └── admin/              # Dashboard, Students, Faculty, Placements, Reports
│   │   ├── hooks/useAuth.tsx       # Auth provider & state management
│   │   ├── services/api.ts         # Axios client
│   │   ├── types/index.ts          # TypeScript interfaces
│   │   ├── App.tsx                 # Full route definition tree
│   │   └── main.tsx                # App bootstrap
│   ├── package.json
│   ├── vite.config.ts
│   └── tailwind.config.js
├── requirements.txt
└── README.md
```

---

## 4. Demo Accounts & Credentials

The database automatically initializes with three role accounts upon backend startup:

| Role | Email ID | Password | Portal Permissions |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin@college.edu` | `Admin@123` | Institutional dashboard, student/faculty directory, departments, placement drives, announcements, and reports |
| **Faculty** | `faculty@college.edu` | `Faculty@123` | Dr. Kumar S. (CSBS) — manage assigned courses (DBMS, Java), enter marks, batch mark attendance, approve ODs |
| **Student** | `student@college.edu` | `Student@123` | Prasanna R. (CSBS Year 2, Sec T20) — view marks, attendance, submit ODs, apply for placements, Smart Insights |

*Note: The login page includes quick one-click autofill buttons for each demo role.*

---

## 5. Local Setup & Running Instructions

### Step 1: Backend Setup (Python FastAPI)

1. Open a terminal in the project directory:
   ```bash
   cd backend
   ```
2. (Optional) Create and activate a virtual environment:
   ```bash
   python3 -m venv venv
   # On macOS/Linux:
   source venv/bin/activate
   # On Windows:
   venv\Scripts\activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the backend server:
   ```bash
   uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
   ```
   *The backend will automatically create `student_erp.sqlite3` and seed demo records if not already populated.*
   - API Docs: `http://localhost:8000/docs`
   - Health check: `http://localhost:8000/health`

### Step 2: Frontend Setup (React + Vite)

1. Open another terminal in the project directory:
   ```bash
   cd frontend
   ```
2. Install npm dependencies:
   ```bash
   npm install
   ```
3. Start the Vite dev server:
   ```bash
   npm run dev
   ```
   - Application URL: `http://localhost:5173`

---

## 6. Novelty Features: The Smart Insights Engine

1. **Smart Attendance Planner**:
   - Computes dynamic subject-wise attendance using verified class records.
   - For subjects below threshold (e.g. 75%): Calculates exact consecutive classes required:
     $$\text{Classes Needed} = \left\lceil \frac{\text{Target} \times \text{Total} - \text{Attended}}{1 - \text{Target}} \right\rceil$$
   - For subjects above threshold: Calculates margin of classes that can be safely missed while staying $\ge$ threshold.
   - Includes interactive threshold sliders (75%, 80%, 85%, 90%).

2. **Academic Early Warning / Risk Indicator**:
   - Transparent rules-based multi-factor evaluation of:
     - Subject attendance shortages ($<75\%$)
     - Internal assessment score declines (Internal 1 vs Internal 2)
     - Cumulative GPA thresholds ($<6.5$)
     - Active backlog arrears
   - Generates risk status (`LOW`, `MODERATE`, `HIGH`), risk score (0–100), itemized factor list, and personalized academic guidance.

3. **What-If CGPA Simulator**:
   - Allows students to select hypothetical expected grades (`O`, `A+`, `A`, `B+`, `B`, `C`, `U`) for their active courses.
   - Dynamically calculates projected Semester SGPA and updated overall CGPA without altering database records.
   - Distinctly labeled `HYPOTHETICAL / PROJECTED`.

---

## 7. Major Cross-System Workflows

- **Workflow A — Continuous Assessments**: Faculty records marks in `/faculty/marks` $\rightarrow$ SQLite updates $\rightarrow$ Student sees updated marks, grade recalculations, and receives in-app notification.
- **Workflow B — Batch Attendance**: Faculty marks class attendance in `/faculty/attendance` $\rightarrow$ SQLite updates $\rightarrow$ Student Attendance ratios, Attendance Planner, and Risk Indicator update instantaneously.
- **Workflow C — Leave / OD Approval**: Student applies in `/student/leave` $\rightarrow$ Faculty sees pending petition in `/faculty/leave` $\rightarrow$ Approve or Reject with feedback $\rightarrow$ Student dashboard shows updated status + explanation.
- **Workflow D — Assignments**: Faculty creates assignment $\rightarrow$ Enrolled students receive notification $\rightarrow$ Student submits solution $\rightarrow$ Faculty grades with feedback $\rightarrow$ Student reviews score.
- **Workflow E — Placement Eligibility**: Admin creates drive with requirements (e.g. CGPA $\ge 7.5$, Backlogs $\le 0$) $\rightarrow$ Eligibility engine verifies student record in real-time $\rightarrow$ Only eligible candidates can apply $\rightarrow$ Admin updates stage (`APPLIED` $\rightarrow$ `SHORTLISTED` $\rightarrow$ `APTITUDE` $\rightarrow$ `TECHNICAL` $\rightarrow$ `HR` $\rightarrow$ `SELECTED`).
- **Workflow F — Announcements**: Admin broadcasts notice targeting `ALL`, `STUDENT`, or `FACULTY` $\rightarrow$ Shared notifications table populated $\rightarrow$ Live bell indicator alerts users.

---

## 8. Resetting the Database

To reset the database back to clean demo data:
```bash
rm -f student_erp.sqlite3
python3 -m backend.seed
```
Restart the backend server to apply fresh state.
