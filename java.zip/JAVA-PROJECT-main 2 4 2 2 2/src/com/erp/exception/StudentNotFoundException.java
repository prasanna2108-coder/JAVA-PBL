package com.erp.exception;

/**
 * Custom checked exception thrown when a requested student ID is not found.
 */
public class StudentNotFoundException extends Exception {
    public StudentNotFoundException(String message) {
        super(message);
    }
}