package com.erp.service;

import com.erp.model.NoDueClearance;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class NoDueService {
    private final Map<String, List<NoDueClearance>> studentClearances = new ConcurrentHashMap<>();

    private static final String[][] SUBJECT_COORDINATORS = {
        {"CS801", "CS801: Distributed Systems", "Prof. Alan Turing"},
        {"CS802", "CS802: Cloud Computing & Virtualization", "Dr. Grace Hopper"},
        {"CS803", "CS803: Deep Learning & Neural Networks", "Dr. Geoffrey Hinton"},
        {"CS804", "CS804: Cryptography & Network Security", "Prof. Ronald Rivest"},
        {"CS805", "CS805: Full-Stack Web Development", "Prof. Tim Berners-Lee"},
        {"CS806", "CS806: Big Data Analytics & Processing", "Dr. Dean Jeffrey"},
        {"CS807", "CS807: Mobile Application Engineering", "Dr. Andy Rubin"},
        {"CS808", "CS808: Capstone Project & Viva Voce", "Prof. Barbara Liskov"}
    };

    private static final String[][] INSTITUTIONAL_OFFICES = {
        {"LIB-01", "Central Library (Book Returns & Zero Dues)", "Mr. K. Ramanathan (Librarian)"},
        {"ACC-01", "Accounts & Finance (Tuition & Exam Fees)", "Mrs. M. Vasanthi (Finance Officer)"},
        {"HST-01", "Hostel & Transport (Clearance & Pass Surrender)", "Warden / Transport Incharge"},
        {"HOD-01", "Head of Department (Academic Clearance Seal)", "Dr. S. Radhakrishnan (HoD, CSE)"}
    };

    public synchronized List<NoDueClearance> getClearancesForStudent(String studentId) {
        return studentClearances.computeIfAbsent(studentId.toUpperCase(), id -> {
            List<NoDueClearance> list = new ArrayList<>();
            int idx = 1;
            for (String[] sub : SUBJECT_COORDINATORS) {
                String clearanceId = "ND-" + studentId + "-" + sub[0];
                NoDueClearance item = new NoDueClearance(clearanceId, studentId, NoDueClearance.Category.SUBJECT, sub[1], sub[2]);
                // Pre-seed some progress for demonstration
                if (idx == 1 || idx == 2) {
                    item.setRecordSubmitted(true);
                    item.setAssignmentsCompleted(true);
                    item.setExamCleared(true);
                    item.approveSignOff(sub[2], "Laboratory record verified, all 5 assignments graded, model exam cleared.");
                } else if (idx == 3) {
                    item.setRecordSubmitted(true);
                    item.setAssignmentsCompleted(true);
                    item.setExamCleared(false);
                    item.setRemarks("Record verified. Pending model exam evaluation.");
                }
                list.add(item);
                idx++;
            }

            for (String[] inst : INSTITUTIONAL_OFFICES) {
                String clearanceId = "ND-" + studentId + "-" + inst[0];
                NoDueClearance.Category cat = switch (inst[0]) {
                    case "LIB-01" -> NoDueClearance.Category.LIBRARY;
                    case "ACC-01" -> NoDueClearance.Category.ACCOUNTS;
                    case "HST-01" -> NoDueClearance.Category.HOSTEL;
                    default -> NoDueClearance.Category.HOD;
                };
                NoDueClearance item = new NoDueClearance(clearanceId, studentId, cat, inst[1], inst[2]);
                if (inst[0].equals("LIB-01") || inst[0].equals("ACC-01")) {
                    item.approveSignOff(inst[2], "Dues verified zero. Formal institutional clearance granted.");
                }
                list.add(item);
            }
            return list;
        });
    }

    public boolean requestSignOff(String studentId, String clearanceId) {
        List<NoDueClearance> list = getClearancesForStudent(studentId);
        for (NoDueClearance c : list) {
            if (c.getId().equalsIgnoreCase(clearanceId) || c.getItemName().toLowerCase().contains(clearanceId.toLowerCase())) {
                c.setRemarks("Sign-off requested by student. Awaiting staff review.");
                return true;
            }
        }
        return false;
    }

    public boolean signOffSubject(String clearanceId, String facultyName, boolean record, boolean assignments, boolean exam, String remarks) {
        for (List<NoDueClearance> list : studentClearances.values()) {
            for (NoDueClearance c : list) {
                if (c.getId().equalsIgnoreCase(clearanceId)) {
                    c.setRecordSubmitted(record);
                    c.setAssignmentsCompleted(assignments);
                    c.setExamCleared(exam);
                    if (record && assignments && exam) {
                        c.approveSignOff(facultyName, remarks);
                    } else {
                        c.setStatus(NoDueClearance.Status.PENDING);
                        c.setRemarks(remarks != null ? remarks : "Pending complete fulfillment of Record/Assignment/Exam.");
                    }
                    return true;
                }
            }
        }
        return false;
    }

    public boolean signOffInstitutional(String clearanceId, String officerName, String remarks) {
        for (List<NoDueClearance> list : studentClearances.values()) {
            for (NoDueClearance c : list) {
                if (c.getId().equalsIgnoreCase(clearanceId)) {
                    c.approveSignOff(officerName, remarks);
                    return true;
                }
            }
        }
        return false;
    }

    public double getClearancePercentage(String studentId) {
        List<NoDueClearance> list = getClearancesForStudent(studentId);
        if (list.isEmpty()) return 0.0;
        long approvedCount = list.stream().filter(c -> c.getStatus() == NoDueClearance.Status.APPROVED).count();
        return (approvedCount * 100.0) / list.size();
    }

    public boolean isAllCleared(String studentId) {
        List<NoDueClearance> list = getClearancesForStudent(studentId);
        return !list.isEmpty() && list.stream().allMatch(c -> c.getStatus() == NoDueClearance.Status.APPROVED);
    }

    public List<NoDueClearance> getAllPendingForFaculty(String facultyKeyword) {
        List<NoDueClearance> result = new ArrayList<>();
        for (List<NoDueClearance> list : studentClearances.values()) {
            for (NoDueClearance c : list) {
                if (c.getStatus() == NoDueClearance.Status.PENDING) {
                    if (facultyKeyword == null || c.getStaffName().toLowerCase().contains(facultyKeyword.toLowerCase())
                            || c.getItemName().toLowerCase().contains(facultyKeyword.toLowerCase())) {
                        result.add(c);
                    }
                }
            }
        }
        return result;
    }
}
