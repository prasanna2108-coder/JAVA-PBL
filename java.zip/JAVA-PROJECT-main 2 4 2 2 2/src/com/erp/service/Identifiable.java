package com.erp.service;

public interface Identifiable {
    String getId();
}