package com.erp.service;

import com.erp.model.Department;
import com.erp.model.GradeRecord;
import com.erp.model.Student;

import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class FileDataPersistence {
    private static final String FILE_PATH = "data/students.txt";

    /**
     * Saves all students and their grades to a physical file on disk.
     */
    public static synchronized void saveToFile(List<Student> students) {
        try {
            Files.createDirectories(Paths.get("data"));
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
                for (Student s : students) {
                    // Line Format: ID|Name|Email|Department
                    writer.write(s.getId() + "|" + s.getName() + "|" + s.getEmail() + "|" + s.getDepartment().name());
                    writer.newLine();

                    // Grade Format: GRADE|CourseCode|CourseName|Score
                    for (GradeRecord g : s.getGrades()) {
                        writer.write("GRADE|" + g.courseCode() + "|" + g.courseName() + "|" + g.score());
                        writer.newLine();
                    }
                    writer.write("END_STUDENT");
                    writer.newLine();
                }
            }
            System.out.println("💾 Data successfully saved to " + FILE_PATH);
        } catch (IOException e) {
            System.err.println("⚠️ Error writing to storage file: " + e.getMessage());
        }
    }

    /**
     * Reads saved student records from disk when the application starts.
     */
    public static synchronized List<Student> loadFromFile() {
        List<Student> loadedStudents = new ArrayList<>();
        File file = new File(FILE_PATH);

        if (!file.exists()) {
            return loadedStudents; // Returns empty list if first run
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            Student currentStudent = null;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                if (line.equals("END_STUDENT")) {
                    if (currentStudent != null) {
                        loadedStudents.add(currentStudent);
                        currentStudent = null;
                    }
                } else if (line.startsWith("GRADE|")) {
                    if (currentStudent != null) {
                        String[] parts = line.split("\\|");
                        String courseCode = parts[1];
                        String courseName = parts[2];
                        double score = Double.parseDouble(parts[3]);
                        currentStudent.addGrade(new GradeRecord(courseCode, courseName, score));
                    }
                } else {
                    String[] parts = line.split("\\|");
                    if (parts.length == 4) {
                        String id = parts[0];
                        String name = parts[1];
                        String email = parts[2];
                        Department dept = Department.valueOf(parts[3]);
                        currentStudent = new Student(id, name, email, dept);
                    }
                }
            }
            System.out.println("📂 Successfully restored " + loadedStudents.size() + " student record(s) from local file database!");
        } catch (IOException e) {
            System.err.println("⚠️ Error reading from storage file: " + e.getMessage());
        }

        return loadedStudents;
    }
}
