package com.erp.service;

import com.erp.dao.StudentDAO;
import com.erp.dao.StudentDAOImpl;
import com.erp.exception.StudentNotFoundException;
import com.erp.model.GradeRecord;
import com.erp.model.Student;
import com.erp.util.AuditLoggerThread;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class StudentServiceImpl implements StudentOperations {
    private final StudentDAO studentDAO = new StudentDAOImpl();

    @Override
    public void registerStudent(Student student) {
        studentDAO.saveStudent(student);
        AuditLoggerThread.logActionAsync("REGISTER_STUDENT_JDBC", "Registered " + student.getId());
    }

    @Override
    public Optional<Student> findStudentById(String id) {
        Student student = studentDAO.getStudentById(id);
        return Optional.ofNullable(student);
    }

    public Student getStudentOrThrow(String id) throws StudentNotFoundException {
        return findStudentById(id)
                .orElseThrow(() -> new StudentNotFoundException("Student with ID '" + id + "' was not found in the database."));
    }

    @Override
    public List<Student> getAllStudents() {
        return studentDAO.getAllStudents();
    }

    @Override
    public double calculateGPA(String studentId) {
        return findStudentById(studentId)
                .map(student -> {
                    List<GradeRecord> grades = student.getGrades();
                    if (grades == null || grades.isEmpty()) return 0.0;
                    return grades.stream()
                            .mapToDouble(GradeRecord::score)
                            .average()
                            .orElse(0.0);
                })
                .orElse(0.0);
    }

    public void addGradeToStudent(String studentId, GradeRecord grade) throws StudentNotFoundException {
        getStudentOrThrow(studentId); // Ensures student exists
        studentDAO.addGrade(studentId, grade);
        AuditLoggerThread.logActionAsync("ADD_GRADE_JDBC", "Added grade " + grade.courseCode() + " to " + studentId);
    }

    @Override
    public String predictAcademicRisk(String studentId) {
        try {
            Student student = getStudentOrThrow(studentId);
            List<GradeRecord> grades = student.getGrades();

            if (grades == null || grades.isEmpty()) return "🟡 STATUS: UNASSESSED.";

            double gpa = calculateGPA(studentId);
            long failingCourses = grades.stream().filter(g -> g.score() < 50.0).count();

            if (gpa < 50.0 || failingCourses >= 2) {
                return "🔴 HIGH RISK: Critical probation warning! Failed (" + failingCourses + ") core subjects.";
            } else if (gpa < 65.0 || failingCourses == 1) {
                return "🟡 MODERATE RISK: Performance is near warning threshold.";
            } else {
                return "🟢 LOW RISK: Satisfactory progress.";
            }
        } catch (StudentNotFoundException e) {
            return "❌ " + e.getMessage();
        }
    }

    @Override
    public Map<String, Object> analyzeScholarshipEligibility(String studentId) {
        Map<String, Object> report = new LinkedHashMap<>();
        try {
            Student student = getStudentOrThrow(studentId);
            double gpa = calculateGPA(studentId);
            List<GradeRecord> grades = student.getGrades();

            report.put("Student ID", student.getId());
            report.put("Student Name", student.getName());
            report.put("Cumulative Avg", String.format("%.2f%%", gpa));

            if (grades == null || grades.isEmpty()) {
                report.put("Eligibility Status", "INELIGIBLE");
                report.put("Decision Reason", "No academic records available.");
                return report;
            }

            boolean hasFailingGrade = grades.stream().anyMatch(g -> g.score() < 50.0);

            if (hasFailingGrade) {
                report.put("Eligibility Status", "INELIGIBLE");
                report.put("Award Tier", "None");
                report.put("Tuition Waiver", "0%");
                report.put("Decision Reason", "Disqualified due to failing marks in 1 or more subjects.");
            } else if (gpa >= 90.0) {
                report.put("Eligibility Status", "ELIGIBLE");
                report.put("Award Tier", "President's Merit Tier 1");
                report.put("Tuition Waiver", "100% Full Scholarship");
            } else if (gpa >= 80.0) {
                report.put("Eligibility Status", "ELIGIBLE");
                report.put("Award Tier", "Dean's Honor Tier 2");
                report.put("Tuition Waiver", "50% Partial Scholarship");
            } else {
                report.put("Eligibility Status", "INELIGIBLE");
                report.put("Tuition Waiver", "0%");
                report.put("Decision Reason", "Average GPA is below 75.0%.");
            }
        } catch (StudentNotFoundException e) {
            report.put("Error", e.getMessage());
        }

        return report;
    }
}