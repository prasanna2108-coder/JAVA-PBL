package com.erp.service;

import com.erp.model.Student;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Service contract defining core CRUD and intelligent analytics operations.
 */
public interface StudentOperations {
    void registerStudent(Student student);
    Optional<Student> findStudentById(String id);
    List<Student> getAllStudents();
    double calculateGPA(String studentId);

    // =========================================================================
    // NOVEL FEATURES CONTRACT
    // =========================================================================
    
    /**
     * NOVELTY 1: Evaluates student GPA, fail count, and trends to predict risk.
     */
    String predictAcademicRisk(String studentId);

    /**
     * NOVELTY 2: Assesses GPA and course records for scholarship tiers & waivers.
     */
    Map<String, Object> analyzeScholarshipEligibility(String studentId);
}