package com.erp.service;

import com.erp.model.AcademicSubject;
import com.erp.util.ConsoleTheme;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class AcademicService {
    private final Map<String, List<AcademicSubject>> studentAcademicRecords = new ConcurrentHashMap<>();

    public synchronized List<AcademicSubject> getSubjectsForStudent(String studentId) {
        return studentAcademicRecords.computeIfAbsent(studentId.toUpperCase(), this::seedSubjectsForStudent);
    }

    private List<AcademicSubject> seedSubjectsForStudent(String id) {
        List<AcademicSubject> list = new ArrayList<>();
        switch (id) {
            case "STU-2024-002" -> { // Aditya Sharma (CSE - Moderate / Solid Improvement)
                list.add(new AcademicSubject("CS801", "Distributed Systems", 4, 25.0, 38.0, "Prof. Alan Turing", 52.0, 63.0));
                list.add(new AcademicSubject("CS802", "Cloud Computing & Virtualization", 3, 27.0, 42.0, "Dr. Grace Hopper", 58.0, 69.0));
                list.add(new AcademicSubject("CS803", "Deep Learning & Neural Networks", 4, 29.0, 43.0, "Dr. Geoffrey Hinton", 60.0, 72.0));
                list.add(new AcademicSubject("CS804", "Cryptography & Network Security", 3, 22.0, 36.0, "Prof. Ronald Rivest", 48.0, 58.0));
                list.add(new AcademicSubject("CS805", "Full-Stack Web Development", 4, 28.0, 46.0, "Prof. Tim Berners-Lee", 62.0, 74.0));
                list.add(new AcademicSubject("CS806", "Big Data Analytics & Processing", 3, 24.0, 37.0, "Dr. Dean Jeffrey", 50.0, 61.0));
                list.add(new AcademicSubject("CS807", "Mobile Application Engineering", 3, 26.0, 40.0, "Dr. Andy Rubin", 55.0, 66.0));
                list.add(new AcademicSubject("CS808", "Capstone Project & Viva Voce", 6, 32.0, 49.0, "Prof. Barbara Liskov", 68.0, 81.0));
            }
            case "STU-2024-003" -> { // Priya Raman (IT - Gold Medalist)
                list.add(new AcademicSubject("IT801", "Enterprise Cloud Architecture", 4, 39.0, 58.0, "Dr. Rajkumar Buyya", 91.0, 97.0));
                list.add(new AcademicSubject("IT802", "Advanced Cyber Security & Forensics", 3, 38.0, 56.0, "Prof. Gene Spafford", 88.0, 94.0));
                list.add(new AcademicSubject("IT803", "Machine Learning & NLP Applications", 4, 39.0, 57.0, "Dr. Christopher Manning", 89.0, 96.0));
                list.add(new AcademicSubject("IT804", "Blockchain & Smart Contracts", 3, 37.0, 55.0, "Prof. Vitalik Buterin", 84.0, 92.0));
                list.add(new AcademicSubject("IT805", "DevOps & Site Reliability Engg", 4, 38.0, 57.0, "Dr. Martin Fowler", 87.0, 95.0));
                list.add(new AcademicSubject("IT806", "Data Warehousing & BI", 3, 36.0, 53.0, "Prof. Ralph Kimball", 82.0, 89.0));
                list.add(new AcademicSubject("IT807", "UI/UX Design & Next-Gen Systems", 3, 37.0, 56.0, "Dr. Don Norman", 85.0, 93.0));
                list.add(new AcademicSubject("IT808", "Industry Capstone Project Defense", 6, 40.0, 59.0, "Dr. Vint Cerf", 92.0, 99.0));
            }
            case "STU-2024-004" -> { // Kavya Senthil (Electronics - High Growth)
                list.add(new AcademicSubject("EC801", "VLSI Design & Verilog HDL", 4, 34.0, 50.0, "Prof. Carver Mead", 71.0, 84.0));
                list.add(new AcademicSubject("EC802", "Embedded Systems & RTOS", 3, 33.0, 49.0, "Dr. Wayne Wolf", 69.0, 82.0));
                list.add(new AcademicSubject("EC803", "Wireless Communication Networks", 4, 35.0, 51.0, "Prof. Andrea Goldsmith", 73.0, 86.0));
                list.add(new AcademicSubject("EC804", "Digital Signal Processing", 3, 31.0, 47.0, "Dr. Alan Oppenheim", 65.0, 78.0));
                list.add(new AcademicSubject("EC805", "IoT Sensors & Edge Computing", 4, 36.0, 53.0, "Prof. Kevin Ashton", 77.0, 89.0));
                list.add(new AcademicSubject("EC806", "RF & Microwave Engineering", 3, 32.0, 48.0, "Dr. David Pozar", 68.0, 80.0));
                list.add(new AcademicSubject("EC807", "Optical Fiber Communication", 3, 34.0, 50.0, "Prof. Gerd Keiser", 72.0, 84.0));
                list.add(new AcademicSubject("EC808", "Hardware Capstone & FPGA Defense", 6, 38.0, 56.0, "Dr. John Hennessy", 83.0, 94.0));
            }
            case "STU-2024-005" -> { // Rahul Verma (Mechanical - Solid Performance)
                list.add(new AcademicSubject("ME801", "Finite Element Analysis (FEA)", 4, 31.0, 47.0, "Prof. O.C. Zienkiewicz", 66.0, 78.0));
                list.add(new AcademicSubject("ME802", "Computational Fluid Dynamics", 3, 30.0, 46.0, "Dr. Suhas Patankar", 64.0, 76.0));
                list.add(new AcademicSubject("ME803", "Robotics & Industrial Automation", 4, 35.0, 52.0, "Prof. Rodney Brooks", 75.0, 87.0));
                list.add(new AcademicSubject("ME804", "Automobile & EV Powertrains", 3, 33.0, 50.0, "Dr. Ferdinand Porsche", 70.0, 83.0));
                list.add(new AcademicSubject("ME805", "Additive Manufacturing & 3D Print", 4, 36.0, 53.0, "Prof. Chuck Hull", 78.0, 89.0));
                list.add(new AcademicSubject("ME806", "Total Quality Management (TQM)", 3, 32.0, 48.0, "Dr. W. Edwards Deming", 69.0, 80.0));
                list.add(new AcademicSubject("ME807", "Heat & Mass Transfer Engineering", 3, 30.0, 45.0, "Prof. Frank Incropera", 63.0, 75.0));
                list.add(new AcademicSubject("ME808", "Mechanical Capstone & Prototype", 6, 37.0, 55.0, "Dr. Henry Ford", 80.0, 92.0));
            }
            case "STU-2024-006" -> { // Divya Bharathi (CSE - Top Scholar)
                list.add(new AcademicSubject("CS801", "Distributed Systems", 4, 38.0, 57.0, "Prof. Alan Turing", 89.0, 95.0));
                list.add(new AcademicSubject("CS802", "Cloud Computing & Virtualization", 3, 37.0, 55.0, "Dr. Grace Hopper", 86.0, 92.0));
                list.add(new AcademicSubject("CS803", "Deep Learning & Neural Networks", 4, 39.0, 58.0, "Dr. Geoffrey Hinton", 92.0, 97.0));
                list.add(new AcademicSubject("CS804", "Cryptography & Network Security", 3, 36.0, 54.0, "Prof. Ronald Rivest", 85.0, 90.0));
                list.add(new AcademicSubject("CS805", "Full-Stack Web Development", 4, 38.0, 56.0, "Prof. Tim Berners-Lee", 88.0, 94.0));
                list.add(new AcademicSubject("CS806", "Big Data Analytics & Processing", 3, 36.0, 55.0, "Dr. Dean Jeffrey", 84.0, 91.0));
                list.add(new AcademicSubject("CS807", "Mobile Application Engineering", 3, 37.0, 56.0, "Dr. Andy Rubin", 87.0, 93.0));
                list.add(new AcademicSubject("CS808", "Capstone Project & Viva Voce", 6, 40.0, 59.0, "Prof. Barbara Liskov", 94.0, 99.0));
            }
            case "STU-2024-007" -> { // Karthik Rajan (IT - Academic Risk Demonstration)
                list.add(new AcademicSubject("IT801", "Enterprise Cloud Architecture", 4, 18.0, 30.0, "Dr. Rajkumar Buyya", 42.0, 48.0));
                list.add(new AcademicSubject("IT802", "Advanced Cyber Security & Forensics", 3, 20.0, 33.0, "Prof. Gene Spafford", 46.0, 53.0));
                list.add(new AcademicSubject("IT803", "Machine Learning & NLP Applications", 4, 21.0, 34.0, "Dr. Christopher Manning", 48.0, 55.0));
                list.add(new AcademicSubject("IT804", "Blockchain & Smart Contracts", 3, 16.0, 28.0, "Prof. Vitalik Buterin", 38.0, 44.0));
                list.add(new AcademicSubject("IT805", "DevOps & Site Reliability Engg", 4, 22.0, 35.0, "Dr. Martin Fowler", 50.0, 57.0));
                list.add(new AcademicSubject("IT806", "Data Warehousing & BI", 3, 19.0, 31.0, "Prof. Ralph Kimball", 44.0, 50.0));
                list.add(new AcademicSubject("IT807", "UI/UX Design & Next-Gen Systems", 3, 20.0, 32.0, "Dr. Don Norman", 45.0, 52.0));
                list.add(new AcademicSubject("IT808", "Industry Capstone Project Defense", 6, 26.0, 40.0, "Dr. Vint Cerf", 58.0, 66.0));
            }
            case "STU-2024-008" -> { // Ananya Deshmukh (Civil - High Achiever)
                list.add(new AcademicSubject("CE801", "Structural Dynamics & Earthquake", 4, 35.0, 52.0, "Prof. Ray Clough", 77.0, 87.0));
                list.add(new AcademicSubject("CE802", "Advanced Reinforced Concrete", 3, 34.0, 51.0, "Dr. Arthur Nilson", 75.0, 85.0));
                list.add(new AcademicSubject("CE803", "Transportation Infrastructure", 4, 36.0, 54.0, "Prof. Adolf May", 80.0, 90.0));
                list.add(new AcademicSubject("CE804", "Environmental Geotechnology", 3, 33.0, 50.0, "Dr. Karl Terzaghi", 73.0, 83.0));
                list.add(new AcademicSubject("CE805", "GIS & Urban Remote Sensing", 4, 37.0, 55.0, "Prof. Roger Tomlinson", 82.0, 92.0));
                list.add(new AcademicSubject("CE806", "Construction Project Management", 3, 34.0, 50.0, "Dr. Daniel Halpin", 76.0, 84.0));
                list.add(new AcademicSubject("CE807", "Water Resources & Hydrology", 3, 35.0, 53.0, "Prof. Ven Te Chow", 78.0, 88.0));
                list.add(new AcademicSubject("CE808", "Civil Capstone Project & BIM", 6, 38.0, 57.0, "Dr. Chuck Eastman", 85.0, 95.0));
            }
            default -> { // Default / STU-2024-001 (Nithya Sree - CSE)
                list.add(new AcademicSubject("CS801", "Distributed Systems", 4, 36.0, 54.0, "Prof. Alan Turing", 74.0, 90.0));
                list.add(new AcademicSubject("CS802", "Cloud Computing & Virtualization", 3, 32.0, 51.0, "Dr. Grace Hopper", 68.0, 83.0));
                list.add(new AcademicSubject("CS803", "Deep Learning & Neural Networks", 4, 38.0, 55.0, "Dr. Geoffrey Hinton", 86.0, 93.0));
                list.add(new AcademicSubject("CS804", "Cryptography & Network Security", 3, 28.0, 48.0, "Prof. Ronald Rivest", 64.0, 76.0));
                list.add(new AcademicSubject("CS805", "Full-Stack Web Development", 4, 35.0, 53.0, "Prof. Tim Berners-Lee", 79.0, 88.0));
                list.add(new AcademicSubject("CS806", "Big Data Analytics & Processing", 3, 31.0, 46.0, "Dr. Dean Jeffrey", 72.0, 77.0));
                list.add(new AcademicSubject("CS807", "Mobile Application Engineering", 3, 34.0, 50.0, "Dr. Andy Rubin", 70.0, 84.0));
                list.add(new AcademicSubject("CS808", "Capstone Project & Viva Voce", 6, 39.0, 58.0, "Prof. Barbara Liskov", 88.0, 97.0));
            }
        }
        return list;
    }

    public synchronized void addOrUpdateSubject(String studentId, String courseCode, String courseName, int credits,
                                                double prevMarks, double currMarks, String facultyName) {
        List<AcademicSubject> subjects = getSubjectsForStudent(studentId);
        for (AcademicSubject s : subjects) {
            if (s.getCourseCode().equalsIgnoreCase(courseCode)) {
                s.setCourseName(courseName);
                s.setCredits(credits);
                s.setPreviousExamMarks(prevMarks);
                s.setCurrentExamMarks(currMarks);
                if (facultyName != null && !facultyName.isBlank()) {
                    s.setFacultyName(facultyName);
                }
                return;
            }
        }
        // If not found, add as a new subject
        double cia = Math.round(currMarks * 0.4 * 10.0) / 10.0;
        double ese = Math.round((currMarks - cia) * 10.0) / 10.0;
        subjects.add(new AcademicSubject(courseCode.toUpperCase(), courseName, credits, cia, ese,
                (facultyName == null || facultyName.isBlank()) ? "Faculty Evaluator" : facultyName,
                prevMarks, currMarks));
    }

    public synchronized boolean renameSubject(String studentId, String courseCode, String newCourseName) {
        List<AcademicSubject> subjects = getSubjectsForStudent(studentId);
        for (AcademicSubject s : subjects) {
            if (s.getCourseCode().equalsIgnoreCase(courseCode)) {
                s.setCourseName(newCourseName);
                return true;
            }
        }
        return false;
    }

    public double calculateSGPA(String studentId) {
        List<AcademicSubject> subjects = getSubjectsForStudent(studentId);
        int totalCredits = 0;
        int totalPoints = 0;
        for (AcademicSubject s : subjects) {
            totalCredits += s.getCredits();
            totalPoints += s.getCredits() * s.getGradePoint();
        }
        return totalCredits > 0 ? (double) totalPoints / totalCredits : 0.0;
    }

    public void updateMarks(String studentId, String courseCode, double ciaMarks, double endSemMarks) {
        List<AcademicSubject> subjects = getSubjectsForStudent(studentId);
        for (AcademicSubject s : subjects) {
            if (s.getCourseCode().equalsIgnoreCase(courseCode)) {
                s.setCiaMarks(ciaMarks);
                s.setEndSemMarks(endSemMarks);
                return;
            }
        }
    }

    public void printExamComparisonGraph(String studentId, String studentName) {
        List<AcademicSubject> subjects = getSubjectsForStudent(studentId);
        if (subjects.isEmpty()) {
            System.out.println(ConsoleTheme.ROSE + "No academic subjects found for student: " + studentId + ConsoleTheme.RESET);
            return;
        }

        ConsoleTheme.printBanner("EXAM PERFORMANCE ANALYTICS — GRAPH COMPARISON");
        System.out.println(ConsoleTheme.BOLD + ConsoleTheme.WHITE + "  Student: " + studentName.toUpperCase() + " (" + studentId + ")" + ConsoleTheme.RESET);
        System.out.println("  " + ConsoleTheme.DIM + "Comparative Performance Analysis: [LAST EXAM] vs [CURRENT / LATEST EXAM]" + ConsoleTheme.RESET);
        System.out.println("  Legend: " + ConsoleTheme.AMBER + "▓ LAST EXAM (Mid-Term/Internal)" + ConsoleTheme.RESET + "   "
                + ConsoleTheme.EMERALD + "█ CURRENT EXAM (Model/Semester)" + ConsoleTheme.RESET);
        System.out.println("─".repeat(84));

        double totalPrev = 0;
        double totalCurr = 0;
        int count = subjects.size();
        AcademicSubject topGrowthSubj = null;
        double maxGrowth = -999.0;
        AcademicSubject topScorer = null;
        double maxScore = -1.0;

        int barScale = 30; // max length for 100%

        for (AcademicSubject s : subjects) {
            double prev = s.getPreviousExamMarks();
            double curr = s.getCurrentExamMarks();
            totalPrev += prev;
            totalCurr += curr;

            double diff = curr - prev;
            if (diff > maxGrowth) {
                maxGrowth = diff;
                topGrowthSubj = s;
            }
            if (curr > maxScore) {
                maxScore = curr;
                topScorer = s;
            }

            int prevFilled = (int) Math.round((prev / 100.0) * barScale);
            prevFilled = Math.max(0, Math.min(barScale, prevFilled));
            String prevBar = ConsoleTheme.AMBER + "▓".repeat(prevFilled) + ConsoleTheme.DARK_GRAY + "░".repeat(barScale - prevFilled) + ConsoleTheme.RESET;

            int currFilled = (int) Math.round((curr / 100.0) * barScale);
            currFilled = Math.max(0, Math.min(barScale, currFilled));
            String currColor = curr >= 75.0 ? ConsoleTheme.EMERALD : (curr >= 50.0 ? ConsoleTheme.CYAN : ConsoleTheme.ROSE);
            String currBar = currColor + "█".repeat(currFilled) + ConsoleTheme.DARK_GRAY + "░".repeat(barScale - currFilled) + ConsoleTheme.RESET;

            String diffTag;
            if (diff > 0) {
                diffTag = ConsoleTheme.EMERALD + String.format("▲ +%.1f pts (Upward Progress)", diff) + ConsoleTheme.RESET;
            } else if (diff < 0) {
                diffTag = ConsoleTheme.ROSE + String.format("▼ %.1f pts (Needs Attention)", diff) + ConsoleTheme.RESET;
            } else {
                diffTag = ConsoleTheme.GRAY + "■ 0.0 pts (Maintained Score)" + ConsoleTheme.RESET;
            }

            System.out.printf("\n  " + ConsoleTheme.BOLD + ConsoleTheme.CYAN + "[%-6s] %s" + ConsoleTheme.RESET + " (Credits: %d | Evaluator: %s)\n",
                    s.getCourseCode(), s.getCourseName(), s.getCredits(), s.getFacultyName());
            System.out.printf("    Last Exam:    [%5.1f/100]  %s %5.1f%%\n", prev, prevBar, prev);
            System.out.printf("    Current Exam: [%5.1f/100]  %s %5.1f%%   %s\n", curr, currBar, curr, diffTag);
        }

        double avgPrev = totalPrev / count;
        double avgCurr = totalCurr / count;
        double netDiff = avgCurr - avgPrev;
        double pctGrowth = avgPrev > 0 ? (netDiff / avgPrev) * 100.0 : 0.0;

        System.out.println("\n" + "─".repeat(84));
        System.out.println(ConsoleTheme.BOLD + ConsoleTheme.INDIGO + "  📊 SUMMARY & EXAM ANALYTICS REPORT" + ConsoleTheme.RESET);
        System.out.printf("  • Previous Exam Batch Average: %s%5.1f%%%s\n", ConsoleTheme.AMBER, avgPrev, ConsoleTheme.RESET);
        System.out.printf("  • Current Exam Batch Average:  %s%5.1f%%%s\n", ConsoleTheme.EMERALD, avgCurr, ConsoleTheme.RESET);
        System.out.printf("  • Net Class Performance Delta: %s%s%5.1f pts (%+.1f%%)%s\n",
                (netDiff >= 0 ? ConsoleTheme.EMERALD : ConsoleTheme.ROSE),
                (netDiff >= 0 ? "▲ +" : "▼ "),
                netDiff, pctGrowth, ConsoleTheme.RESET);
        if (topGrowthSubj != null && maxGrowth > 0) {
            System.out.printf("  • Highest Improving Subject:   %s%s - %s (+%.1f pts) 🚀%s\n",
                    ConsoleTheme.CYAN, topGrowthSubj.getCourseCode(), topGrowthSubj.getCourseName(), maxGrowth, ConsoleTheme.RESET);
        }
        if (topScorer != null) {
            System.out.printf("  • Top Scoring Subject:         %s%s - %s (%.1f/100) 🏆%s\n",
                    ConsoleTheme.EMERALD, topScorer.getCourseCode(), topScorer.getCourseName(), maxScore, ConsoleTheme.RESET);
        }
        System.out.println("─".repeat(84));
    }

    public void printOfficialMarksheet(String studentId, String studentName, String dept, double attendance) {
        List<AcademicSubject> subjects = getSubjectsForStudent(studentId);
        double sgpa = calculateSGPA(studentId);

        System.out.println("\n" + ConsoleTheme.INDIGO + "╔════════════════════════════════════════════════════════════════════════════════════════╗" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "║" + ConsoleTheme.BOLD + ConsoleTheme.WHITE + "                         CHENNAI INSTITUTE OF TECHNOLOGY                        " + ConsoleTheme.INDIGO + "║" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "║" + ConsoleTheme.CYAN + "                  OFFICIAL SEMESTER GRADE REPORT (SEMESTER VIII)                 " + ConsoleTheme.INDIGO + "║" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "╠════════════════════════════════════════════════════════════════════════════════════════╣" + ConsoleTheme.RESET);
        System.out.printf(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.WHITE + "Student: %-26s Roll No: %-15s Dept: %-16s" + ConsoleTheme.INDIGO + "║\n" + ConsoleTheme.RESET,
                studentName, studentId, dept);
        System.out.printf(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.WHITE + "Academic Year: 2025-2026            Semester: VIII                Attendance: %5.1f%%   " + ConsoleTheme.INDIGO + "║\n" + ConsoleTheme.RESET,
                attendance);
        System.out.println(ConsoleTheme.INDIGO + "╠════════════════════════════════════════════════════════════════════════════════════════╣" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.BOLD + ConsoleTheme.AMBER + "CODE   COURSE TITLE                       CR  CIA/40  ESE/60  TOTAL/100  GR  PTS  RES " + ConsoleTheme.INDIGO + "║" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "╟────────────────────────────────────────────────────────────────────────────────────────╢" + ConsoleTheme.RESET);

        int totalCred = 0;
        int totalPts = 0;
        for (AcademicSubject s : subjects) {
            totalCred += s.getCredits();
            totalPts += s.getCredits() * s.getGradePoint();
            String resTag = s.isPassed() ? ConsoleTheme.EMERALD + "PASS" + ConsoleTheme.RESET : ConsoleTheme.ROSE + "FAIL" + ConsoleTheme.RESET;
            System.out.printf(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.RESET + "%-6s %-33s %2d   %5.1f   %5.1f    %5.1f     %-2s   %2d  %s " + ConsoleTheme.INDIGO + "║\n" + ConsoleTheme.RESET,
                    s.getCourseCode(),
                    s.getCourseName().length() > 33 ? s.getCourseName().substring(0, 30) + "..." : s.getCourseName(),
                    s.getCredits(),
                    s.getCiaMarks(),
                    s.getEndSemMarks(),
                    s.getTotalMarks(),
                    s.getGradeLetter(),
                    s.getGradePoint(),
                    resTag);
        }

        System.out.println(ConsoleTheme.INDIGO + "╠════════════════════════════════════════════════════════════════════════════════════════╣" + ConsoleTheme.RESET);
        double cgpa = Math.round(Math.min(10.0, Math.max(4.0, sgpa * 0.985)) * 100.0) / 100.0;
        String classification = cgpa >= 8.5 ? "FIRST CLASS WITH DISTINCTION" : (cgpa >= 6.5 ? "FIRST CLASS" : "SECOND CLASS");
        System.out.printf(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.BOLD + ConsoleTheme.WHITE + "TOTAL CREDITS REGISTERED: %-4d | EARNED GRADE POINTS: %-4d | SGPA: %s%-5.2f%s | CGPA: %s%-5.2f%s " + ConsoleTheme.INDIGO + "║\n" + ConsoleTheme.RESET,
                totalCred, totalPts, ConsoleTheme.EMERALD, sgpa, ConsoleTheme.WHITE, ConsoleTheme.CYAN, cgpa, ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "╠════════════════════════════════════════════════════════════════════════════════════════╣" + ConsoleTheme.RESET);
        System.out.printf(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.GRAY + "Classification: %-32s Barcode Ref: CIT-8SEM-2026-OK   " + ConsoleTheme.INDIGO + "║\n" + ConsoleTheme.RESET, classification);
        System.out.println(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.DIM + "Digitally Signed by: Office of the Controller of Examinations, CIT               " + ConsoleTheme.INDIGO + "║" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "╚════════════════════════════════════════════════════════════════════════════════════════╝" + ConsoleTheme.RESET);
    }
}
