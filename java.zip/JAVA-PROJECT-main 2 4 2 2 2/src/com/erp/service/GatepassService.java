package com.erp.service;

import com.erp.model.Gatepass;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class GatepassService {
    private final Map<String, Gatepass> gatepasses = new ConcurrentHashMap<>();
    private int counter = 2000;

    public Gatepass issueGatepass(String studentId, String destination, String departureTime,
                                  String returnTime, String reason, String parentContact, String approvedBy) {
        String passId = "GP-" + (++counter);
        Gatepass gp = new Gatepass(passId, studentId, destination, reason, departureTime, returnTime, parentContact, approvedBy);
        gatepasses.put(passId, gp);
        return gp;
    }

    public List<Gatepass> getGatepassesByStudent(String studentId) {
        return gatepasses.values().stream()
                .filter(gp -> gp.getStudentId().equalsIgnoreCase(studentId))
                .sorted(Comparator.comparing(Gatepass::getPassId).reversed())
                .collect(Collectors.toList());
    }

    public Optional<Gatepass> findById(String passId) {
        return Optional.ofNullable(gatepasses.get(passId.toUpperCase()));
    }
}
