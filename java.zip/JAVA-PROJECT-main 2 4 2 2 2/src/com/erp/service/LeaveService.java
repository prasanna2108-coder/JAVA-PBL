package com.erp.service;

import com.erp.model.LeaveODRequest;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class LeaveService {
    private final Map<String, LeaveODRequest> requests = new HashMap<>();
    private int counter = 1000;

    public String applyLeaveOrOD(String studentId, LeaveODRequest.RequestType type, LocalDate start, LocalDate end, String reason) {
        String requestId = "REQ-" + (++counter);
        LeaveODRequest request = new LeaveODRequest(requestId, studentId, type, start, end, reason);
        requests.put(requestId, request);
        return requestId;
    }

    public List<LeaveODRequest> getRequestsByStudent(String studentId) {
        return requests.values().stream()
                .filter(r -> r.getStudentId().equalsIgnoreCase(studentId))
                .collect(Collectors.toList());
    }

    public List<LeaveODRequest> getAllPendingRequests() {
        return requests.values().stream()
                .filter(r -> r.getStatus() == LeaveODRequest.RequestStatus.PENDING)
                .collect(Collectors.toList());
    }

    public boolean updateStatus(String requestId, LeaveODRequest.RequestStatus newStatus) {
        LeaveODRequest req = requests.get(requestId);
        if (req != null) {
            req.setStatus(newStatus);
            return true;
        }
        return false;
    }
}