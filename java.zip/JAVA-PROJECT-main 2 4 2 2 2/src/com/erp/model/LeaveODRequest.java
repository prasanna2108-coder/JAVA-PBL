package com.erp.model;

import java.time.LocalDate;

public class LeaveODRequest {
    public enum RequestType { LEAVE, ON_DUTY }
    public enum RequestStatus { PENDING, APPROVED, REJECTED }

    private final String requestId;
    private final String studentId;
    private final RequestType type;
    private final LocalDate startDate;
    private final LocalDate endDate;
    private final String reason;
    private RequestStatus status;

    public LeaveODRequest(String requestId, String studentId, RequestType type, LocalDate startDate, LocalDate endDate, String reason) {
        this.requestId = requestId;
        this.studentId = studentId;
        this.type = type;
        this.startDate = startDate;
        this.endDate = endDate;
        this.reason = reason;
        this.status = RequestStatus.PENDING;
    }

    public String getRequestId() { return requestId; }
    public String getStudentId() { return studentId; }
    public RequestType getType() { return type; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public String getReason() { return reason; }
    public RequestStatus getStatus() { return status; }
    public void setStatus(RequestStatus status) { this.status = status; }

    @Override
    public String toString() {
        return String.format("ID: %-8s | Type: %-7s | Dates: %s to %s | Status: %-8s | Reason: %s",
                requestId, type, startDate, endDate, status, reason);
    }
}