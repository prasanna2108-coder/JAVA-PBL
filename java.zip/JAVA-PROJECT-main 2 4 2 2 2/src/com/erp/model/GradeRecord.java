package com.erp.model;

public record GradeRecord(String courseCode, String courseName, double score) {
}