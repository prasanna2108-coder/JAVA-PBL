package com.erp.model;

public class AcademicSubject {
    private final String courseCode;
    private String courseName;
    private int credits;
    private double ciaMarks; // Max 40
    private double endSemMarks; // Max 60
    private double previousExamMarks; // Last Exam score (0-100)
    private double currentExamMarks;  // Current/Latest Exam score (0-100)
    private String facultyName;

    public AcademicSubject(String courseCode, String courseName, int credits, double ciaMarks, double endSemMarks, String facultyName) {
        this(courseCode, courseName, credits, ciaMarks, endSemMarks, facultyName,
                Math.round(Math.max(40.0, (ciaMarks + endSemMarks) - 12.0) * 10.0) / 10.0,
                ciaMarks + endSemMarks);
    }

    public AcademicSubject(String courseCode, String courseName, int credits, double ciaMarks, double endSemMarks,
                           String facultyName, double previousExamMarks, double currentExamMarks) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.credits = credits;
        this.ciaMarks = ciaMarks;
        this.endSemMarks = endSemMarks;
        this.facultyName = facultyName;
        this.previousExamMarks = previousExamMarks;
        this.currentExamMarks = currentExamMarks;
    }

    public String getCourseCode() { return courseCode; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }

    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }

    public double getCiaMarks() { return ciaMarks; }
    public void setCiaMarks(double ciaMarks) {
        this.ciaMarks = ciaMarks;
        this.currentExamMarks = this.ciaMarks + this.endSemMarks;
    }

    public double getEndSemMarks() { return endSemMarks; }
    public void setEndSemMarks(double endSemMarks) {
        this.endSemMarks = endSemMarks;
        this.currentExamMarks = this.ciaMarks + this.endSemMarks;
    }

    public double getPreviousExamMarks() { return previousExamMarks; }
    public void setPreviousExamMarks(double previousExamMarks) { this.previousExamMarks = previousExamMarks; }

    public double getCurrentExamMarks() { return currentExamMarks; }
    public void setCurrentExamMarks(double currentExamMarks) {
        this.currentExamMarks = currentExamMarks;
        this.ciaMarks = Math.round(currentExamMarks * 0.4 * 10.0) / 10.0;
        this.endSemMarks = Math.round((currentExamMarks - this.ciaMarks) * 10.0) / 10.0;
    }

    public String getFacultyName() { return facultyName; }
    public void setFacultyName(String facultyName) { this.facultyName = facultyName; }

    public double getTotalMarks() {
        return ciaMarks + endSemMarks;
    }

    public String getGradeLetter() {
        double total = getTotalMarks();
        if (total >= 90) return "O";
        if (total >= 80) return "A+";
        if (total >= 70) return "A";
        if (total >= 60) return "B+";
        if (total >= 50) return "B";
        return "RA";
    }

    public int getGradePoint() {
        double total = getTotalMarks();
        if (total >= 90) return 10;
        if (total >= 80) return 9;
        if (total >= 70) return 8;
        if (total >= 60) return 7;
        if (total >= 50) return 6;
        return 0;
    }

    public boolean isPassed() {
        return getTotalMarks() >= 50.0 && endSemMarks >= 27.0; // 45% in End-Sem
    }
}
