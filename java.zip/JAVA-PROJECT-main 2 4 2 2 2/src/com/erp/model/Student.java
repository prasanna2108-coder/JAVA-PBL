package com.erp.model;

import java.util.ArrayList;
import java.util.List;

public class Student extends Person {
    private double attendance;
    private double feeDueAmount;
    private List<GradeRecord> grades = new ArrayList<>();

    // 4-Parameter Constructor
    public Student(String id, String name, String email, Department department) {
        super(id, name, email, department);
        this.attendance = 100.0;
        this.feeDueAmount = 0.0;
    }

    // 6-Parameter Constructor
    public Student(String id, String name, String email, Department department, double attendance, double feeDueAmount) {
        super(id, name, email, department);
        this.attendance = attendance;
        this.feeDueAmount = feeDueAmount;
    }

    // Attendance Getters & Setters
    public double getAttendance() { 
        return attendance; 
    }
    
    public double getAttendancePercentage() { 
        return attendance; 
    }

    public void setAttendance(double attendance) { 
        this.attendance = attendance; 
    }

    public void setAttendancePercentage(double attendance) { 
        this.attendance = attendance; 
    }

    // Fee Due Getters & Setters
    public double getFeeDueAmount() { 
        return feeDueAmount; 
    }

    public void setFeeDueAmount(double feeDueAmount) { 
        this.feeDueAmount = feeDueAmount; 
    }

    // Grades List Getters & Setters
    public List<GradeRecord> getGrades() { 
        if (this.grades == null) {
            this.grades = new ArrayList<>();
        }
        return grades; 
    }

    public void setGrades(List<GradeRecord> grades) { 
        this.grades = grades; 
    }

    // Helper method to add individual grades directly
    public void addGrade(GradeRecord grade) {
        if (this.grades == null) {
            this.grades = new ArrayList<>();
        }
        this.grades.add(grade);
    }

    // Helper method for ReportGenerator compatibility
    public String getRoleDetails() {
        return "Student [ID=" + getId() + "]";
    }
}