package com.erp.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class NoDueClearance {
    public enum Category { SUBJECT, LIBRARY, ACCOUNTS, HOSTEL, HOD }
    public enum Status { PENDING, APPROVED }

    private final String id;
    private final String studentId;
    private final Category category;
    private final String itemName;
    private final String staffName;
    private boolean recordSubmitted;
    private boolean assignmentsCompleted;
    private boolean examCleared;
    private Status status;
    private String remarks;
    private String signedAt;

    public NoDueClearance(String id, String studentId, Category category, String itemName, String staffName) {
        this.id = id;
        this.studentId = studentId;
        this.category = category;
        this.itemName = itemName;
        this.staffName = staffName;
        this.recordSubmitted = false;
        this.assignmentsCompleted = false;
        this.examCleared = false;
        this.status = Status.PENDING;
        this.remarks = "Pending submission and staff review";
        this.signedAt = null;
    }

    public NoDueClearance(String id, String studentId, Category category, String itemName, String staffName,
                          boolean recordSubmitted, boolean assignmentsCompleted, boolean examCleared,
                          Status status, String remarks, String signedAt) {
        this.id = id;
        this.studentId = studentId;
        this.category = category;
        this.itemName = itemName;
        this.staffName = staffName;
        this.recordSubmitted = recordSubmitted;
        this.assignmentsCompleted = assignmentsCompleted;
        this.examCleared = examCleared;
        this.status = status;
        this.remarks = remarks;
        this.signedAt = signedAt;
    }

    public String getId() { return id; }
    public String getStudentId() { return studentId; }
    public Category getCategory() { return category; }
    public String getItemName() { return itemName; }
    public String getStaffName() { return staffName; }
    public boolean isRecordSubmitted() { return recordSubmitted; }
    public void setRecordSubmitted(boolean recordSubmitted) { this.recordSubmitted = recordSubmitted; }
    public boolean isAssignmentsCompleted() { return assignmentsCompleted; }
    public void setAssignmentsCompleted(boolean assignmentsCompleted) { this.assignmentsCompleted = assignmentsCompleted; }
    public boolean isExamCleared() { return examCleared; }
    public void setExamCleared(boolean examCleared) { this.examCleared = examCleared; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
    public String getSignedAt() { return signedAt; }
    public void setSignedAt(String signedAt) { this.signedAt = signedAt; }

    public void approveSignOff(String staffVerifier, String notes) {
        this.status = Status.APPROVED;
        this.remarks = notes != null && !notes.isBlank() ? notes : "Verified and signed off";
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        this.signedAt = LocalDateTime.now().format(dtf) + " by " + staffVerifier;
    }

    public boolean isFullyFulfilled() {
        if (category == Category.SUBJECT) {
            return recordSubmitted && assignmentsCompleted && examCleared;
        }
        return status == Status.APPROVED;
    }
}
