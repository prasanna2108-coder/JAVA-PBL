package com.erp.model;

public enum Role {
    ADMIN,
    STAFF,
    STUDENT
}