package com.erp.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Gatepass {
    public enum Status { ISSUED, USED, EXPIRED, CANCELLED }

    private final String passId;
    private final String studentId;
    private final String destination;
    private final String reason;
    private final String departureTime;
    private final String returnTime;
    private final String parentContact;
    private final String verificationToken;
    private Status status;
    private String approvedBy;
    private String generatedAt;

    public Gatepass(String passId, String studentId, String destination, String reason,
                    String departureTime, String returnTime, String parentContact, String approvedBy) {
        this.passId = passId;
        this.studentId = studentId;
        this.destination = destination;
        this.reason = reason;
        this.departureTime = departureTime;
        this.returnTime = returnTime;
        this.parentContact = parentContact;
        this.approvedBy = approvedBy;
        this.status = Status.ISSUED;
        this.generatedAt = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        this.verificationToken = "SEC-" + Math.abs(passId.hashCode() % 90000 + 10000);
    }

    public String getPassId() { return passId; }
    public String getStudentId() { return studentId; }
    public String getDestination() { return destination; }
    public String getReason() { return reason; }
    public String getDepartureTime() { return departureTime; }
    public String getReturnTime() { return returnTime; }
    public String getParentContact() { return parentContact; }
    public String getVerificationToken() { return verificationToken; }
    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }
    public String getApprovedBy() { return approvedBy; }
    public String getGeneratedAt() { return generatedAt; }
}
