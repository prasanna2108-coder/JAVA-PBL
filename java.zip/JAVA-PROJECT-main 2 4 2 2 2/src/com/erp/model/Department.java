package com.erp.model;

/**
 * Department Enum demonstrating Java constants and static utility methods.
 */
public enum Department {
    COMPUTER_SCIENCE("CS", "Computer Science & Engineering"),
    INFORMATION_TECHNOLOGY("IT", "Information Technology"),
    ELECTRONICS("ECE", "Electronics & Communication"), CIVIL_ENGINEERING("CIV", "Civil Engineering"), MECHANICAL_ENGINEERING("ME", "Mechanical Engineering"), ELECTRONICS_COMMUNICATION("EC", "Electronics & Communication");

    private final String code;
    private final String fullName;

    Department(String code, String fullName) {
        this.code = code;
        this.fullName = fullName;
    }

    public String getCode() {
        return code;
    }

    public String getFullName() {
        return fullName;
    }
}