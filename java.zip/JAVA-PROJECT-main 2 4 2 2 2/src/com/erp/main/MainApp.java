package com.erp.main;

import com.erp.dao.StudentDAO;
import com.erp.dao.StudentDAOImpl;
import com.erp.model.*;
import com.erp.service.*;
import com.erp.util.ConsoleTheme;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class MainApp {
    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentDAO studentDAO = new StudentDAOImpl();
    private static final AcademicService academicService = new AcademicService();
    private static final NoDueService noDueService = new NoDueService();
    private static final LeaveService leaveService = new LeaveService();
    private static final GatepassService gatepassService = new GatepassService();

    public static void main(String[] args) {
        // Pre-seed initial gatepass and leave for demonstration
        leaveService.applyLeaveOrOD("STU-2024-001", LeaveODRequest.RequestType.ON_DUTY,
                LocalDate.now().plusDays(2), LocalDate.now().plusDays(4), "Smart India Hackathon 2026 Grand Finale");
        gatepassService.issueGatepass("STU-2024-001", "Central Library / City Tech Park",
                "15:30", "19:00", "Project Research Collaboration", "+91 98401 23456", "Chief Warden");

        while (true) {
            ConsoleTheme.printHeader("CHENNAI INSTITUTE OF TECHNOLOGY",
                    "Unified College Student ERP & Smart Academic Analytics — Terminal CLI");

            System.out
                    .println(ConsoleTheme.BOLD + ConsoleTheme.CYAN + "  [DEMO LOGIN CREDENTIALS & SAMPLE STUDENTS FOR DEMO]" + ConsoleTheme.RESET);
            System.out.println("  • " + ConsoleTheme.WHITE + "Staff Portal:   " + ConsoleTheme.RESET + "User: "
                    + ConsoleTheme.EMERALD + "staff" + ConsoleTheme.RESET + " | Pass: " + ConsoleTheme.EMERALD
                    + "staff123" + ConsoleTheme.RESET);
            System.out.println("  • " + ConsoleTheme.WHITE + "Admin Portal:   " + ConsoleTheme.RESET + "User: "
                    + ConsoleTheme.EMERALD + "admin" + ConsoleTheme.RESET + " | Pass: " + ConsoleTheme.EMERALD
                    + "admin123" + ConsoleTheme.RESET);
            System.out.println("  • " + ConsoleTheme.WHITE + "Sample Students for Quick Demo:" + ConsoleTheme.RESET);
            System.out.println("    " + ConsoleTheme.CYAN + "STU-2024-001" + ConsoleTheme.RESET + " ➔ Nithya Sree   (CSE - High Achiever, 88.5% Attn, 9.27 SGPA)");
            System.out.println("    " + ConsoleTheme.CYAN + "STU-2024-002" + ConsoleTheme.RESET + " ➔ Aditya Sharma (CSE - Moderate/Growth, 71.0% Attn, Fee Due $1,250)");
            System.out.println("    " + ConsoleTheme.CYAN + "STU-2024-003" + ConsoleTheme.RESET + " ➔ Priya Raman   (IT  - Gold Medalist, 94.5% Attn, 9.60 SGPA)");
            System.out.println("    " + ConsoleTheme.CYAN + "STU-2024-004" + ConsoleTheme.RESET + " ➔ Kavya Senthil (ECE - High Growth, 82.0% Attn, 8.53 SGPA)");
            System.out.println("    " + ConsoleTheme.CYAN + "STU-2024-005" + ConsoleTheme.RESET + " ➔ Rahul Verma   (ME  - Solid Improver, 78.5% Attn, 8.30 SGPA)");
            System.out.println("    " + ConsoleTheme.CYAN + "STU-2024-006" + ConsoleTheme.RESET + " ➔ Divya Bharathi(CSE - 96% Scholar, 9.50 SGPA)");
            System.out.println("    " + ConsoleTheme.CYAN + "STU-2024-007" + ConsoleTheme.RESET + " ➔ Karthik Rajan (IT  - Risk Demo: 68.0% Attn, Fee Due $3,200)");
            System.out.println("    " + ConsoleTheme.CYAN + "STU-2024-008" + ConsoleTheme.RESET + " ➔ Ananya Deshmukh(Civil - High Achiever, 89.0% Attn, 8.80 SGPA)");
            System.out.println("─".repeat(88));

            System.out.println(ConsoleTheme.BOLD + "SELECT PORTAL TO ENTER:" + ConsoleTheme.RESET);
            System.out.println(
                    "  " + ConsoleTheme.CYAN + "1." + ConsoleTheme.RESET + " 🎓 Student Academic & Clearance Portal");
            System.out.println("  " + ConsoleTheme.CYAN + "2." + ConsoleTheme.RESET
                    + " 👨‍🏫 Faculty / Staff Portal (Marks & No-Due Sign-Off)");
            System.out.println("  " + ConsoleTheme.CYAN + "3." + ConsoleTheme.RESET
                    + " 🏛️ Administrator Portal (Enrollment & Institution Audit)");
            System.out.println("  " + ConsoleTheme.CYAN + "4." + ConsoleTheme.RESET + " 🚪 Exit Application");
            System.out.print(ConsoleTheme.BOLD + "\nEnter your choice (1-4): " + ConsoleTheme.RESET);

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> studentPortalLogin();
                case "2" -> facultyPortalLogin();
                case "3" -> adminPortalLogin();
                case "4" -> {
                    System.out.println("\n" + ConsoleTheme.EMERALD
                            + "✔ Thank you for using College Student ERP. Session terminated safely."
                            + ConsoleTheme.RESET);
                    System.exit(0);
                }
                default -> System.out.println("\n" + ConsoleTheme.ROSE
                        + "✖ Invalid selection. Please choose an option from 1 to 4." + ConsoleTheme.RESET);
            }
        }
    }

    // ==========================================
    // 🎓 STUDENT PORTAL
    // ==========================================
    private static void studentPortalLogin() {
        System.out.println("\n" + ConsoleTheme.BOLD + ConsoleTheme.CYAN + "AVAILABLE DEMO STUDENTS FOR PRESENTATION:" + ConsoleTheme.RESET);
        System.out.println("  1. " + ConsoleTheme.EMERALD + "STU-2024-001" + ConsoleTheme.RESET + " ➔ Nithya Sree   (CSE Topper - 88.5% Attn, 9.27 SGPA)");
        System.out.println("  2. " + ConsoleTheme.EMERALD + "STU-2024-002" + ConsoleTheme.RESET + " ➔ Aditya Sharma (CSE Moderate - 71.0% Attn, Due: $1,250)");
        System.out.println("  3. " + ConsoleTheme.EMERALD + "STU-2024-003" + ConsoleTheme.RESET + " ➔ Priya Raman   (IT Gold Medalist - 94.5% Attn, 9.60 SGPA)");
        System.out.println("  4. " + ConsoleTheme.EMERALD + "STU-2024-004" + ConsoleTheme.RESET + " ➔ Kavya Senthil (ECE High Growth - 82.0% Attn, 8.53 SGPA)");
        System.out.println("  5. " + ConsoleTheme.EMERALD + "STU-2024-005" + ConsoleTheme.RESET + " ➔ Rahul Verma   (ME Solid Improver - 78.5% Attn, 8.30 SGPA)");
        System.out.println("  6. " + ConsoleTheme.EMERALD + "STU-2024-006" + ConsoleTheme.RESET + " ➔ Divya Bharathi(CSE Scholar - 96.0% Attn, 9.50 SGPA)");
        System.out.println("  7. " + ConsoleTheme.EMERALD + "STU-2024-007" + ConsoleTheme.RESET + " ➔ Karthik Rajan (IT Critical Risk - 68.0% Attn, Due: $3,200)");
        System.out.println("  8. " + ConsoleTheme.EMERALD + "STU-2024-008" + ConsoleTheme.RESET + " ➔ Ananya Deshmukh(Civil High Achiever - 89.0% Attn, 8.80 SGPA)");
        System.out.print("\n" + ConsoleTheme.BOLD + "Enter Student ID or list number 1-8 (Press Enter for STU-2024-001): "
                + ConsoleTheme.RESET);
        String input = scanner.nextLine().trim();
        if (input.isEmpty()) {
            input = "STU-2024-001";
        } else {
            input = switch (input) {
                case "1" -> "STU-2024-001";
                case "2" -> "STU-2024-002";
                case "3" -> "STU-2024-003";
                case "4" -> "STU-2024-004";
                case "5" -> "STU-2024-005";
                case "6" -> "STU-2024-006";
                case "7" -> "STU-2024-007";
                case "8" -> "STU-2024-008";
                default -> input;
            };
        }

        Student student = studentDAO.getStudentById(input);
        if (student == null) {
            // Try matching by email
            for (Student s : studentDAO.getAllStudents()) {
                if (s.getEmail().equalsIgnoreCase(input)) {
                    student = s;
                    break;
                }
            }
        }

        if (student == null) {
            System.out.println(ConsoleTheme.ROSE + "✖ Student record not found for: " + input + ConsoleTheme.RESET);
            return;
        }

        while (true) {
            ConsoleTheme.printBanner(
                    "STUDENT DASHBOARD — " + student.getName().toUpperCase() + " (" + student.getId() + ")");
            System.out.println("  " + ConsoleTheme.DIM + "Department: " + student.getDepartment() + " | Attendance: "
                    + student.getAttendancePercentage() + "% | Fee Due: $" + student.getFeeDueAmount()
                    + ConsoleTheme.RESET);
            System.out.println("─".repeat(80));

            System.out.println("  " + ConsoleTheme.CYAN + "1." + ConsoleTheme.RESET
                    + " 📄 View Official Semester Marksheet (8 Subjects + CGPA)");
            System.out.println("  " + ConsoleTheme.CYAN + "2." + ConsoleTheme.RESET
                    + " 📋 No Due Clearance System (8 Subjects + Staff Sign-Offs)");
            System.out.println(
                    "  " + ConsoleTheme.CYAN + "3." + ConsoleTheme.RESET + " 📝 Apply for Leave or On-Duty (OD)");
            System.out.println(
                    "  " + ConsoleTheme.CYAN + "4." + ConsoleTheme.RESET + " 📜 View Leave & OD Application History");
            System.out.println(
                    "  " + ConsoleTheme.CYAN + "5." + ConsoleTheme.RESET + " 🎫 Generate Security Outpass / Gatepass");
            System.out.println("  " + ConsoleTheme.CYAN + "6." + ConsoleTheme.RESET
                    + " 🧠 Smart Insights (Attendance Planner, Risk & What-If CGPA)");
            System.out.println("  " + ConsoleTheme.CYAN + "7." + ConsoleTheme.RESET
                    + " 📊 Exam Comparison Analytics (Graph: Last Exam vs Current Exam)");
            System.out.println("  " + ConsoleTheme.CYAN + "8." + ConsoleTheme.RESET + " ↩ Logout to Main Menu");
            System.out.print(ConsoleTheme.BOLD + "\nEnter your choice (1-8): " + ConsoleTheme.RESET);

            String ch = scanner.nextLine().trim();
            switch (ch) {
                case "1" -> academicService.printOfficialMarksheet(student.getId(), student.getName(),
                        student.getDepartment().name(), student.getAttendancePercentage());
                case "2" -> handleStudentClearance(student);
                case "3" -> handleStudentLeaveApplication(student);
                case "4" -> handleStudentLeaveHistory(student);
                case "5" -> handleStudentGatepass(student);
                case "6" -> handleStudentSmartInsights(student);
                case "7" -> academicService.printExamComparisonGraph(student.getId(), student.getName());
                case "8" -> {
                    return;
                }
                default -> System.out.println(ConsoleTheme.ROSE + "✖ Invalid option." + ConsoleTheme.RESET);
            }
        }
    }

    private static void handleStudentClearance(Student student) {
        while (true) {
            List<NoDueClearance> clearances = noDueService.getClearancesForStudent(student.getId());
            double progress = noDueService.getClearancePercentage(student.getId());

            ConsoleTheme.printBanner("INSTITUTIONAL NO DUE CLEARANCE — " + student.getName().toUpperCase());
            System.out.println("Overall Clearance Progress: " + ConsoleTheme.progressBar(progress, 30));
            System.out.println("Status: " + (noDueService.isAllCleared(student.getId())
                    ? ConsoleTheme.EMERALD + "✔ FULLY CLEARED FOR CONVOCATION / HALL TICKET" + ConsoleTheme.RESET
                    : ConsoleTheme.AMBER + "⏳ CLEARANCE IN PROGRESS" + ConsoleTheme.RESET));
            System.out.println("─".repeat(80));

            System.out.println(ConsoleTheme.BOLD + ConsoleTheme.WHITE
                    + "SECTION A: 8 ENROLLED SUBJECT COORDINATOR CLEARANCES" + ConsoleTheme.RESET);
            System.out.printf(ConsoleTheme.DIM + "%-10s %-32s %-8s %-8s %-8s %-12s\n" + ConsoleTheme.RESET,
                    "ID", "Subject / Coordinator", "Record", "Assign", "Exam", "Sign-Off");
            System.out.println("─".repeat(80));

            for (NoDueClearance c : clearances) {
                if (c.getCategory() == NoDueClearance.Category.SUBJECT) {
                    String rec = c.isRecordSubmitted() ? ConsoleTheme.EMERALD + "✔ Done" + ConsoleTheme.RESET
                            : ConsoleTheme.ROSE + "✖ Pend" + ConsoleTheme.RESET;
                    String ass = c.isAssignmentsCompleted() ? ConsoleTheme.EMERALD + "✔ Done" + ConsoleTheme.RESET
                            : ConsoleTheme.ROSE + "✖ Pend" + ConsoleTheme.RESET;
                    String exm = c.isExamCleared() ? ConsoleTheme.EMERALD + "✔ Done" + ConsoleTheme.RESET
                            : ConsoleTheme.ROSE + "✖ Pend" + ConsoleTheme.RESET;
                    System.out.printf("%-10s %-32s %-17s %-17s %-17s %s\n",
                            c.getId().substring(Math.max(0, c.getId().length() - 8)),
                            c.getItemName().length() > 32 ? c.getItemName().substring(0, 29) + "..." : c.getItemName(),
                            rec, ass, exm,
                            ConsoleTheme.statusBadge(c.getStatus().name()));
                }
            }

            System.out.println("\n" + ConsoleTheme.BOLD + ConsoleTheme.WHITE
                    + "SECTION B: INSTITUTIONAL & DEPARTMENTAL OFFICES" + ConsoleTheme.RESET);
            System.out.println("─".repeat(80));
            for (NoDueClearance c : clearances) {
                if (c.getCategory() != NoDueClearance.Category.SUBJECT) {
                    System.out.printf("%-10s %-45s %-15s %s\n",
                            c.getId().substring(Math.max(0, c.getId().length() - 8)),
                            c.getItemName(),
                            c.getStaffName().split(" ")[0],
                            ConsoleTheme.statusBadge(c.getStatus().name()));
                }
            }
            System.out.println("─".repeat(80));

            System.out.println("1. Request Sign-Off from Subject Coordinator / Office");
            System.out.println("2. Generate & View Official No Due Clearance Certificate");
            System.out.println("3. Back to Student Dashboard");
            System.out.print(ConsoleTheme.BOLD + "Enter choice (1-3): " + ConsoleTheme.RESET);

            String choice = scanner.nextLine().trim();
            if ("1".equals(choice)) {
                System.out.print("Enter Subject Code or Clearance ID (e.g. CS803 or LIB-01): ");
                String ref = scanner.nextLine().trim();
                boolean ok = noDueService.requestSignOff(student.getId(), ref);
                if (ok) {
                    System.out.println("\n" + ConsoleTheme.EMERALD
                            + "✔ Sign-off request logged. Notification dispatched to coordinator."
                            + ConsoleTheme.RESET);
                } else {
                    System.out.println("\n" + ConsoleTheme.ROSE + "✖ Could not locate clearance item matching: " + ref
                            + ConsoleTheme.RESET);
                }
            } else if ("2".equals(choice)) {
                printNoDueCertificateTerminal(student, clearances, progress);
            } else if ("3".equals(choice)) {
                break;
            }
        }
    }

    private static void printNoDueCertificateTerminal(Student student, List<NoDueClearance> clearances,
            double progress) {
        System.out.println("\n" + ConsoleTheme.INDIGO
                + "╔════════════════════════════════════════════════════════════════════════════════════════╗"
                + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "║" + ConsoleTheme.BOLD + ConsoleTheme.WHITE
                + "                         CHENNAI INSTITUTE OF TECHNOLOGY                        "
                + ConsoleTheme.INDIGO + "║" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "║" + ConsoleTheme.CYAN
                + "                 OFFICIAL INSTITUTIONAL NO DUE CLEARANCE CERTIFICATE              "
                + ConsoleTheme.INDIGO + "║" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO
                + "╠════════════════════════════════════════════════════════════════════════════════════════╣"
                + ConsoleTheme.RESET);
        System.out.printf(
                ConsoleTheme.INDIGO + "║ " + ConsoleTheme.WHITE
                        + "Candidate Name: %-25s Register No: %-15s Dept: %-14s " + ConsoleTheme.INDIGO + "║\n"
                        + ConsoleTheme.RESET,
                student.getName(), student.getId(), student.getDepartment());
        System.out.printf(
                ConsoleTheme.INDIGO + "║ " + ConsoleTheme.WHITE
                        + "Clearance Level: %-5.1f%% Approved          Convocation Ready: %-25s " + ConsoleTheme.INDIGO
                        + "║\n" + ConsoleTheme.RESET,
                progress, progress == 100.0 ? "YES (CERTIFIED)" : "PROVISIONAL");
        System.out.println(ConsoleTheme.INDIGO
                + "╠════════════════════════════════════════════════════════════════════════════════════════╣"
                + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.AMBER
                + "SL  DEPARTMENT / SUBJECT                 RECORD    ASSIGN    EXAM    CLEARANCE STATUS    "
                + ConsoleTheme.INDIGO + "║" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO
                + "╟────────────────────────────────────────────────────────────────────────────────────────╢"
                + ConsoleTheme.RESET);

        int i = 1;
        for (NoDueClearance c : clearances) {
            String name = c.getItemName().length() > 32 ? c.getItemName().substring(0, 29) + "..." : c.getItemName();
            String r = c.getCategory() == NoDueClearance.Category.SUBJECT
                    ? (c.isRecordSubmitted() ? "VERIFIED" : "PENDING ")
                    : "N/A     ";
            String a = c.getCategory() == NoDueClearance.Category.SUBJECT
                    ? (c.isAssignmentsCompleted() ? "COMPLTD " : "PENDING ")
                    : "N/A     ";
            String e = c.getCategory() == NoDueClearance.Category.SUBJECT
                    ? (c.isExamCleared() ? "CLEARED " : "PENDING ")
                    : "N/A     ";
            String st = c.getStatus() == NoDueClearance.Status.APPROVED
                    ? ConsoleTheme.EMERALD + "APPROVED" + ConsoleTheme.RESET
                    : ConsoleTheme.AMBER + "PENDING " + ConsoleTheme.RESET;

            System.out.printf(
                    ConsoleTheme.INDIGO + "║ " + ConsoleTheme.RESET + "%-3d %-35s %-9s %-9s %-7s %-19s"
                            + ConsoleTheme.INDIGO + "║\n" + ConsoleTheme.RESET,
                    i++, name, r, a, e, st);
        }

        System.out.println(ConsoleTheme.INDIGO
                + "╠════════════════════════════════════════════════════════════════════════════════════════╣"
                + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.DIM
                + "Digital Audit Hash: SHA256:7f89d38102a9b3c4e8f1          Ref: ND-BIHER-2026-FINAL"
                + ConsoleTheme.INDIGO + "║" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO + "║ " + ConsoleTheme.BOLD + ConsoleTheme.WHITE
                + "Endorsed by: Dean (Academic Courses) & Head of Institution                               "
                + ConsoleTheme.INDIGO + "║" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.INDIGO
                + "╚════════════════════════════════════════════════════════════════════════════════════════╝"
                + ConsoleTheme.RESET);
    }

    private static void handleStudentLeaveApplication(Student student) {
        ConsoleTheme.printBanner("APPLY FOR LEAVE OR ON-DUTY (OD)");
        System.out.println("1. Academic / Medical Leave");
        System.out.println("2. On-Duty (OD) for Hackathon / Symposium / Sports");
        System.out.print("Select type (1-2): ");
        String typeChoice = scanner.nextLine().trim();
        LeaveODRequest.RequestType type = "2".equals(typeChoice) ? LeaveODRequest.RequestType.ON_DUTY
                : LeaveODRequest.RequestType.LEAVE;

        System.out.print("Enter Start Date (YYYY-MM-DD): ");
        String sDate = scanner.nextLine().trim();
        System.out.print("Enter End Date (YYYY-MM-DD): ");
        String eDate = scanner.nextLine().trim();
        System.out.print("Enter Detailed Purpose: ");
        String reason = scanner.nextLine().trim();

        try {
            LocalDate start = LocalDate.parse(sDate);
            LocalDate end = LocalDate.parse(eDate);
            String reqId = leaveService.applyLeaveOrOD(student.getId(), type, start, end, reason);
            System.out.println("\n" + ConsoleTheme.EMERALD + "✔ Application submitted successfully! Tracking ID: "
                    + reqId + ConsoleTheme.RESET);
        } catch (Exception e) {
            System.out
                    .println(ConsoleTheme.ROSE + "✖ Invalid date format. Please use YYYY-MM-DD." + ConsoleTheme.RESET);
        }
    }

    private static void handleStudentLeaveHistory(Student student) {
        ConsoleTheme.printBanner("APPLICATION HISTORY — " + student.getName().toUpperCase());
        List<LeaveODRequest> list = leaveService.getRequestsByStudent(student.getId());
        if (list.isEmpty()) {
            System.out.println(ConsoleTheme.AMBER + "No leave or OD applications on record." + ConsoleTheme.RESET);
        } else {
            for (LeaveODRequest req : list) {
                System.out.printf("• Tracking: %-9s | Type: %-7s | Dates: %s to %s | Status: %s | Reason: %s\n",
                        req.getRequestId(), req.getType(), req.getStartDate(), req.getEndDate(),
                        ConsoleTheme.statusBadge(req.getStatus().name()), req.getReason());
            }
        }
    }

    private static void handleStudentGatepass(Student student) {
        ConsoleTheme.printBanner("SECURITY CAMPUS OUTPASS / GATEPASS GENERATOR");
        System.out.println("1. Issue New Campus Gatepass");
        System.out.println("2. View Active / Issued Gatepasses");
        System.out.print("Enter choice (1-2): ");
        String ch = scanner.nextLine().trim();

        if ("1".equals(ch)) {
            System.out.print("Enter Destination: ");
            String dest = scanner.nextLine().trim();
            System.out.print("Enter Departure Time (e.g. 16:30): ");
            String dep = scanner.nextLine().trim();
            System.out.print("Enter Expected Return Time (e.g. 20:00): ");
            String ret = scanner.nextLine().trim();
            System.out.print("Enter Purpose / Reason: ");
            String reason = scanner.nextLine().trim();
            System.out.print("Enter Parent Contact Number: ");
            String phone = scanner.nextLine().trim();

            Gatepass gp = gatepassService.issueGatepass(student.getId(), dest, dep, ret, reason, phone,
                    "Faculty Advisor");
            System.out.println("\n" + ConsoleTheme.EMERALD + "✔ Security Gatepass Generated! Pass ID: " + gp.getPassId()
                    + ConsoleTheme.RESET);
            printGatepassTerminal(gp, student);
        } else {
            List<Gatepass> list = gatepassService.getGatepassesByStudent(student.getId());
            if (list.isEmpty()) {
                System.out.println(ConsoleTheme.AMBER + "No gatepasses issued for this student." + ConsoleTheme.RESET);
            } else {
                for (Gatepass gp : list) {
                    printGatepassTerminal(gp, student);
                }
            }
        }
    }

    private static void printGatepassTerminal(Gatepass gp, Student student) {
        System.out.println("\n" + ConsoleTheme.ROSE
                + "┌────────────────────────────────────────────────────────────────────────┐" + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.ROSE + "│" + ConsoleTheme.BOLD + ConsoleTheme.WHITE
                + "             CAMPUS SECURITY GATEPASS — STUDENT OUTPASS                 " + ConsoleTheme.ROSE + "│"
                + ConsoleTheme.RESET);
        System.out.println(ConsoleTheme.ROSE
                + "├────────────────────────────────────────────────────────────────────────┤" + ConsoleTheme.RESET);
        System.out.printf(
                ConsoleTheme.ROSE + "│ " + ConsoleTheme.WHITE + "Pass ID: %-18s Student: %-22s Dept: %-10s "
                        + ConsoleTheme.ROSE + "│\n" + ConsoleTheme.RESET,
                gp.getPassId(), student.getName(), student.getDepartment());
        System.out.printf(
                ConsoleTheme.ROSE + "│ " + ConsoleTheme.WHITE + "Out: %-10s In: %-10s Destination: %-26s "
                        + ConsoleTheme.ROSE + "│\n" + ConsoleTheme.RESET,
                gp.getDepartureTime(), gp.getReturnTime(), gp.getDestination());
        System.out.printf(
                ConsoleTheme.ROSE + "│ " + ConsoleTheme.WHITE + "Parent Phone: %-15s Reason: %-32s " + ConsoleTheme.ROSE
                        + "│\n" + ConsoleTheme.RESET,
                gp.getParentContact(),
                gp.getReason().length() > 32 ? gp.getReason().substring(0, 29) + "..." : gp.getReason());
        System.out.printf(
                ConsoleTheme.ROSE + "│ " + ConsoleTheme.CYAN + "Verification Security Code: %-15s Status: %-21s "
                        + ConsoleTheme.ROSE + "│\n" + ConsoleTheme.RESET,
                gp.getVerificationToken(), ConsoleTheme.statusBadge(gp.getStatus().name()));
        System.out.println(ConsoleTheme.ROSE
                + "└────────────────────────────────────────────────────────────────────────┘" + ConsoleTheme.RESET);
    }

    private static void handleStudentSmartInsights(Student student) {
        ConsoleTheme.printBanner("SMART INSIGHTS SUITE — ACADEMIC INTELLIGENCE");
        System.out.println("1. 🎯 Consecutive Attendance Planner (Achieve 75% or 85%)");
        System.out.println("2. ⚠️ Academic Risk Early Warning Indicator");
        System.out.println("3. 📈 What-If CGPA Simulator");
        System.out.println("4. 📊 Exam Comparison Analytics (Last Exam vs Current Exam Bar Graph)");
        System.out.print("Select tool (1-4): ");
        String opt = scanner.nextLine().trim();

        if ("1".equals(opt)) {
            System.out.println("\n--- CONSECUTIVE ATTENDANCE PLANNER ---");
            System.out.print("Enter total lectures delivered so far (e.g. 120): ");
            int total = Integer.parseInt(scanner.nextLine().trim());
            System.out.print("Enter lectures attended by you (e.g. 106): ");
            int attended = Integer.parseInt(scanner.nextLine().trim());
            System.out.print("Enter target attendance % (e.g. 75 or 85): ");
            double target = Double.parseDouble(scanner.nextLine().trim());

            double curPct = ((double) attended / total) * 100.0;
            System.out.printf("\nCurrent Attendance: %.2f%%\n", curPct);

            if (curPct >= target) {
                // How many can miss
                int canMiss = (int) Math.floor((attended - (target / 100.0) * total) / (target / 100.0));
                System.out.println(ConsoleTheme.EMERALD + "✔ Safe Margin: You can miss up to " + canMiss
                        + " upcoming classes and remain at or above " + target + "%." + ConsoleTheme.RESET);
            } else {
                // How many consecutive must attend
                int needed = (int) Math.ceil(((target / 100.0) * total - attended) / (1 - (target / 100.0)));
                System.out.println(ConsoleTheme.ROSE + "⚠️ Action Required: You must attend " + needed
                        + " consecutive lectures with zero absences to achieve " + target + "%." + ConsoleTheme.RESET);
            }
        } else if ("2".equals(opt)) {
            System.out.println("\n--- ACADEMIC RISK EARLY WARNING ---");
            double gpa = academicService.calculateSGPA(student.getId());
            double att = student.getAttendancePercentage();
            System.out.printf("Calculated Semester SGPA: %.2f / 10.0\n", gpa);
            System.out.printf("Current Attendance Rate:  %.1f%%\n", att);

            if (att < 75.0 || gpa < 6.0) {
                System.out.println(ConsoleTheme.ROSE
                        + "🔴 CRITICAL RISK: Student is in danger of exam debarment or academic probation!"
                        + ConsoleTheme.RESET);
            } else if (att < 80.0 || gpa < 7.5) {
                System.out.println(ConsoleTheme.AMBER
                        + "🟡 MODERATE RISK: Approaching attendance / marks caution threshold." + ConsoleTheme.RESET);
            } else {
                System.out.println(
                        ConsoleTheme.EMERALD + "🟢 LOW RISK / SAFE STANDING: Consistent high-tier academic performance."
                                + ConsoleTheme.RESET);
            }
        } else if ("3".equals(opt)) {
            System.out.println("\n--- WHAT-IF CGPA SIMULATOR ---");
            System.out.print("Enter your current Cumulative GPA (CGPA) (e.g. 8.90): ");
            double curCgpa = Double.parseDouble(scanner.nextLine().trim());
            System.out.print("Enter total credits completed till last semester (e.g. 130): ");
            int pastCredits = Integer.parseInt(scanner.nextLine().trim());
            System.out.print("Enter expected GPA for this semester's 30 credits (e.g. 9.5): ");
            double expectedSgpa = Double.parseDouble(scanner.nextLine().trim());

            int newTotal = pastCredits + 30;
            double projCgpa = ((curCgpa * pastCredits) + (expectedSgpa * 30)) / newTotal;
            System.out.printf("\n%sProjected Cumulative CGPA upon graduation: %.2f / 10.0%s\n",
                    ConsoleTheme.BOLD + ConsoleTheme.EMERALD, projCgpa, ConsoleTheme.RESET);
        } else if ("4".equals(opt)) {
            academicService.printExamComparisonGraph(student.getId(), student.getName());
        }
    }

    // ==========================================
    // 👨‍🏫 FACULTY / STAFF PORTAL
    // ==========================================
    private static void facultyPortalLogin() {
        System.out.print("\nEnter Faculty Username (staff): ");
        String u = scanner.nextLine().trim();
        System.out.print("Enter Faculty Password (staff123): ");
        String p = scanner.nextLine().trim();

        if (!"staff".equalsIgnoreCase(u) || !"staff123".equals(p)) {
            System.out.println(ConsoleTheme.ROSE + "✖ Invalid faculty credentials." + ConsoleTheme.RESET);
            return;
        }

        while (true) {
            ConsoleTheme.printBanner("FACULTY / STAFF PORTAL — DEPT OF COMPUTER SCIENCE");
            System.out.println("  " + ConsoleTheme.CYAN + "1." + ConsoleTheme.RESET
                    + " ✍️ No Due Clearance Review & Sign-Off (Record, Assignments, Exam)");
            System.out.println("  " + ConsoleTheme.CYAN + "2." + ConsoleTheme.RESET
                    + " ➕ Register / Add New Student");
            System.out.println("  " + ConsoleTheme.CYAN + "3." + ConsoleTheme.RESET
                    + " 📝 Add / Update Marks (Type Any Subject Name & Custom Code)");
            System.out.println("  " + ConsoleTheme.CYAN + "4." + ConsoleTheme.RESET
                    + " ✏️ Change / Rename Subject Name");
            System.out.println("  " + ConsoleTheme.CYAN + "5." + ConsoleTheme.RESET
                    + " 📊 Batch Grade Entry for Enrolled Courses (CIA & End-Sem)");
            System.out.println("  " + ConsoleTheme.CYAN + "6." + ConsoleTheme.RESET + " 👥 View Class Student Roster");
            System.out.println("  " + ConsoleTheme.CYAN + "7." + ConsoleTheme.RESET
                    + " 📋 Approve / Reject Student Leave & OD Applications");
            System.out.println("  " + ConsoleTheme.CYAN + "8." + ConsoleTheme.RESET
                    + " 📈 View Student Exam Comparison Analytics (Graph View)");
            System.out.println("  " + ConsoleTheme.CYAN + "9." + ConsoleTheme.RESET + " ↩ Logout to Main Menu");
            System.out.print(ConsoleTheme.BOLD + "\nEnter your choice (1-9): " + ConsoleTheme.RESET);

            String ch = scanner.nextLine().trim();
            switch (ch) {
                case "1" -> handleFacultyNoDueSignOff();
                case "2" -> handleFacultyAddNewStudent();
                case "3" -> handleFacultyAddMarksCustomSubject();
                case "4" -> handleFacultyChangeSubjectName();
                case "5" -> handleFacultyGradeEntry();
                case "6" -> handleFacultyRoster();
                case "7" -> handleFacultyLeaveApprovals();
                case "8" -> handleFacultyExamAnalytics();
                case "9" -> {
                    return;
                }
                default -> System.out.println(ConsoleTheme.ROSE + "✖ Invalid option. Please choose an option from 1 to 9." + ConsoleTheme.RESET);
            }
        }
    }

    private static void handleFacultyNoDueSignOff() {
        ConsoleTheme.printBanner("NO DUE CLEARANCE VERIFICATION & SIGN-OFF");
        System.out.print("Enter Student ID to review clearance (e.g. STU-2024-001): ");
        String sid = scanner.nextLine().trim();
        List<NoDueClearance> list = noDueService.getClearancesForStudent(sid);

        System.out.println("\nClearance Checklist for " + sid + ":");
        for (int i = 0; i < list.size(); i++) {
            NoDueClearance c = list.get(i);
            System.out.printf("[%2d] %-40s | Status: %s\n", (i + 1), c.getItemName(),
                    ConsoleTheme.statusBadge(c.getStatus().name()));
        }

        System.out.print("\nSelect item number to verify & sign (1-" + list.size() + "): ");
        int sel = Integer.parseInt(scanner.nextLine().trim()) - 1;
        if (sel >= 0 && sel < list.size()) {
            NoDueClearance c = list.get(sel);
            if (c.getCategory() == NoDueClearance.Category.SUBJECT) {
                System.out.print("Is Laboratory Record Notebook verified & submitted? (y/n): ");
                boolean rec = "y".equalsIgnoreCase(scanner.nextLine().trim());
                System.out.print("Are all Internal Assignments completed? (y/n): ");
                boolean ass = "y".equalsIgnoreCase(scanner.nextLine().trim());
                System.out.print("Is Model Examination cleared? (y/n): ");
                boolean exm = "y".equalsIgnoreCase(scanner.nextLine().trim());
                System.out.print("Enter Staff Verification Remarks: ");
                String rem = scanner.nextLine().trim();

                noDueService.signOffSubject(c.getId(), "Dr. Faculty Evaluator", rec, ass, exm, rem);
                System.out.println(ConsoleTheme.EMERALD + "✔ Subject clearance updated and signed successfully!"
                        + ConsoleTheme.RESET);
            } else {
                System.out.print("Enter Institutional Office Approval Remarks: ");
                String rem = scanner.nextLine().trim();
                noDueService.signOffInstitutional(c.getId(), "Chief Institutional Officer", rem);
                System.out.println(
                        ConsoleTheme.EMERALD + "✔ Institutional clearance stamped & signed!" + ConsoleTheme.RESET);
            }
        }
    }

    private static void handleFacultyGradeEntry() {
        ConsoleTheme.printBanner("BATCH COURSE GRADE ENTRY");
        System.out.print("Enter Student ID (e.g. STU-2024-001): ");
        String sid = scanner.nextLine().trim();
        System.out.print("Enter Course Code to update (e.g. CS801): ");
        String code = scanner.nextLine().trim();
        System.out.print("Enter Continuous Internal Assessment (CIA) marks (0-40): ");
        double cia = Double.parseDouble(scanner.nextLine().trim());
        System.out.print("Enter End Semester Examination (ESE) marks (0-60): ");
        double ese = Double.parseDouble(scanner.nextLine().trim());

        academicService.updateMarks(sid, code, cia, ese);
        System.out.println(ConsoleTheme.EMERALD + "✔ Marks updated successfully! Total: " + (cia + ese) + "/100."
                + ConsoleTheme.RESET);
    }

    private static void handleFacultyRoster() {
        ConsoleTheme.printBanner("ENROLLED STUDENT ROSTER — ACADEMIC YEAR 2025-2026");
        List<Student> students = studentDAO.getAllStudents();
        System.out.printf(ConsoleTheme.BOLD + "%-14s %-20s %-25s %-12s %-10s %s\n" + ConsoleTheme.RESET,
                "Roll No / ID", "Student Name", "Department", "Attendance", "SGPA", "Fee Dues");
        System.out.println("─".repeat(88));
        for (Student s : students) {
            double sgpa = academicService.calculateSGPA(s.getId());
            String attnColor = s.getAttendancePercentage() < 75.0 ? ConsoleTheme.ROSE : (s.getAttendancePercentage() < 85.0 ? ConsoleTheme.AMBER : ConsoleTheme.EMERALD);
            System.out.printf("%-14s %-20s %-25s %s%5.1f%%%s       %-10.2f $%.2f\n",
                    s.getId(), s.getName(), s.getDepartment(), attnColor, s.getAttendancePercentage(), ConsoleTheme.RESET, sgpa, s.getFeeDueAmount());
        }
        System.out.println("─".repeat(88));
    }

    private static void handleFacultyLeaveApprovals() {
        ConsoleTheme.printBanner("PENDING LEAVE & ON-DUTY APPROVALS");
        List<LeaveODRequest> pending = leaveService.getAllPendingRequests();
        if (pending.isEmpty()) {
            System.out.println(ConsoleTheme.AMBER + "No pending leave or OD requests to process." + ConsoleTheme.RESET);
            return;
        }

        for (LeaveODRequest r : pending) {
            System.out.println(r);
        }
        System.out.print("\nEnter Request ID to update: ");
        String reqId = scanner.nextLine().trim();
        System.out.print("Decision (1: Approve, 2: Reject): ");
        String dec = scanner.nextLine().trim();
        LeaveODRequest.RequestStatus status = "1".equals(dec) ? LeaveODRequest.RequestStatus.APPROVED
                : LeaveODRequest.RequestStatus.REJECTED;
        if (leaveService.updateStatus(reqId, status)) {
            System.out.println(ConsoleTheme.EMERALD + "✔ Request status updated to " + status + ConsoleTheme.RESET);
        } else {
            System.out.println(ConsoleTheme.ROSE + "✖ Invalid Request ID." + ConsoleTheme.RESET);
        }
    }

    private static void handleFacultyAddNewStudent() {
        ConsoleTheme.printBanner("FACULTY — REGISTER NEW STUDENT");
        System.out.print("Enter New Student ID (e.g. STU-2024-006): ");
        String id = scanner.nextLine().trim();
        if (id.isEmpty()) {
            System.out.println(ConsoleTheme.ROSE + "✖ Student ID cannot be empty." + ConsoleTheme.RESET);
            return;
        }

        if (studentDAO.getStudentById(id) != null) {
            System.out.println(ConsoleTheme.ROSE + "✖ Student with ID " + id + " already exists." + ConsoleTheme.RESET);
            return;
        }

        System.out.print("Enter Student Full Name: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) name = "New Student";

        System.out.print("Enter Student Email: ");
        String email = scanner.nextLine().trim();
        if (email.isEmpty()) email = id.toLowerCase() + "@college.edu";

        System.out.println("Select Department:");
        System.out.println("  1. COMPUTER_SCIENCE (Default)");
        System.out.println("  2. INFORMATION_TECHNOLOGY");
        System.out.println("  3. ELECTRONICS");
        System.out.println("  4. MECHANICAL_ENGINEERING");
        System.out.println("  5. CIVIL_ENGINEERING");
        System.out.print("Enter department choice (1-5, Enter for 1): ");
        String deptChoice = scanner.nextLine().trim();
        Department dept = switch (deptChoice) {
            case "2" -> Department.INFORMATION_TECHNOLOGY;
            case "3" -> Department.ELECTRONICS;
            case "4" -> Department.MECHANICAL_ENGINEERING;
            case "5" -> Department.CIVIL_ENGINEERING;
            default -> Department.COMPUTER_SCIENCE;
        };

        System.out.print("Enter Initial Attendance Percentage (e.g. 88.5, Enter for 85.0%): ");
        String attStr = scanner.nextLine().trim();
        double attendance = 85.0;
        try {
            if (!attStr.isEmpty()) attendance = Double.parseDouble(attStr);
        } catch (NumberFormatException ignored) {}

        System.out.print("Enter Fee Due Amount ($) (Enter for $0.00): ");
        String feeStr = scanner.nextLine().trim();
        double feeDue = 0.0;
        try {
            if (!feeStr.isEmpty()) feeDue = Double.parseDouble(feeStr);
        } catch (NumberFormatException ignored) {}

        Student student = new Student(id, name, email, dept, attendance, feeDue);
        studentDAO.saveStudent(student);

        // Pre-initialize default academic subjects so marksheet & analytics work immediately
        academicService.getSubjectsForStudent(id);

        System.out.println("\n" + ConsoleTheme.EMERALD
                + "✔ Student " + name + " (" + id + ") registered successfully and saved to Database!"
                + ConsoleTheme.RESET);
    }

    private static void handleFacultyAddMarksCustomSubject() {
        ConsoleTheme.printBanner("FACULTY — ADD / UPDATE MARKS (CUSTOM SUBJECT ENTRY)");
        System.out.print("Enter Student ID (e.g. STU-2024-001): ");
        String sid = scanner.nextLine().trim();
        if (sid.isEmpty()) sid = "STU-2024-001";

        Student student = studentDAO.getStudentById(sid);
        String sName = student != null ? student.getName() : sid;
        System.out.println(ConsoleTheme.DIM + "Editing marks for: " + sName + " (" + sid + ")" + ConsoleTheme.RESET);

        System.out.print("Enter Course Code (e.g. CS809, AI801, or existing code): ");
        String code = scanner.nextLine().trim().toUpperCase();
        if (code.isEmpty()) {
            System.out.println(ConsoleTheme.ROSE + "✖ Subject code cannot be empty." + ConsoleTheme.RESET);
            return;
        }

        System.out.print("Enter Subject Name (type whatever subject title you want): ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) name = "Advanced " + code;

        System.out.print("Enter Subject Credits (1-6, Enter for 3): ");
        String credStr = scanner.nextLine().trim();
        int credits = 3;
        try {
            if (!credStr.isEmpty()) credits = Integer.parseInt(credStr);
        } catch (NumberFormatException ignored) {}

        System.out.print("Enter LAST Exam Marks (0-100, e.g. 72.0): ");
        double prevMarks = 70.0;
        try {
            prevMarks = Double.parseDouble(scanner.nextLine().trim());
        } catch (NumberFormatException ignored) {}

        System.out.print("Enter CURRENT / LATEST Exam Marks (0-100, e.g. 88.5): ");
        double currMarks = 85.0;
        try {
            currMarks = Double.parseDouble(scanner.nextLine().trim());
        } catch (NumberFormatException ignored) {}

        System.out.print("Enter Faculty Evaluator Name (Enter for 'Dr. Faculty Evaluator'): ");
        String faculty = scanner.nextLine().trim();
        if (faculty.isEmpty()) faculty = "Dr. Faculty Evaluator";

        // Save in AcademicService
        academicService.addOrUpdateSubject(sid, code, name, credits, prevMarks, currMarks, faculty);

        // Also record grade in DAO
        studentDAO.addGrade(sid, new GradeRecord(code, name, currMarks));

        System.out.println("\n" + ConsoleTheme.EMERALD
                + "✔ Marks and Subject [" + code + " - " + name + "] successfully saved!" + ConsoleTheme.RESET);
        System.out.printf("  • Last Exam Score:    %s%.1f / 100%s\n", ConsoleTheme.AMBER, prevMarks, ConsoleTheme.RESET);
        System.out.printf("  • Current Exam Score: %s%.1f / 100%s\n", ConsoleTheme.EMERALD, currMarks, ConsoleTheme.RESET);
        double diff = currMarks - prevMarks;
        System.out.printf("  • Score Differential: %s%s%.1f points%s\n",
                diff >= 0 ? ConsoleTheme.EMERALD : ConsoleTheme.ROSE,
                diff >= 0 ? "▲ +" : "▼ ", diff, ConsoleTheme.RESET);
    }

    private static void handleFacultyChangeSubjectName() {
        ConsoleTheme.printBanner("FACULTY — RENAME / EDIT SUBJECT NAME");
        System.out.print("Enter Student ID (e.g. STU-2024-001): ");
        String sid = scanner.nextLine().trim();
        if (sid.isEmpty()) sid = "STU-2024-001";

        List<AcademicSubject> subjects = academicService.getSubjectsForStudent(sid);
        if (subjects.isEmpty()) {
            System.out.println(ConsoleTheme.ROSE + "No subjects registered for student: " + sid + ConsoleTheme.RESET);
            return;
        }

        System.out.println("\nCurrent Subjects Registered for " + sid + ":");
        for (int i = 0; i < subjects.size(); i++) {
            AcademicSubject s = subjects.get(i);
            System.out.printf("  [%d] %-7s : %s\n", (i + 1), s.getCourseCode(), s.getCourseName());
        }

        System.out.print("\nEnter Subject Code to rename (e.g. CS801) or list number (1-" + subjects.size() + "): ");
        String input = scanner.nextLine().trim();
        String targetCode = input;
        try {
            int idx = Integer.parseInt(input) - 1;
            if (idx >= 0 && idx < subjects.size()) {
                targetCode = subjects.get(idx).getCourseCode();
            }
        } catch (NumberFormatException ignored) {}

        AcademicSubject matched = null;
        for (AcademicSubject s : subjects) {
            if (s.getCourseCode().equalsIgnoreCase(targetCode)) {
                matched = s;
                break;
            }
        }

        if (matched == null) {
            System.out.println(ConsoleTheme.ROSE + "✖ Subject code " + targetCode + " not found." + ConsoleTheme.RESET);
            return;
        }

        System.out.println("Current Subject Name: " + ConsoleTheme.CYAN + matched.getCourseName() + ConsoleTheme.RESET);
        System.out.print("Enter NEW Subject Name: ");
        String newName = scanner.nextLine().trim();
        if (newName.isEmpty()) {
            System.out.println(ConsoleTheme.ROSE + "✖ Subject name cannot be empty." + ConsoleTheme.RESET);
            return;
        }

        String oldName = matched.getCourseName();
        academicService.renameSubject(sid, matched.getCourseCode(), newName);

        System.out.println("\n" + ConsoleTheme.EMERALD + "✔ Subject [" + matched.getCourseCode() + "] renamed successfully!" + ConsoleTheme.RESET);
        System.out.println("  Old Name: " + ConsoleTheme.GRAY + oldName + ConsoleTheme.RESET);
        System.out.println("  New Name: " + ConsoleTheme.BOLD + ConsoleTheme.CYAN + newName + ConsoleTheme.RESET);
    }

    private static void handleFacultyExamAnalytics() {
        System.out.print("\nEnter Student ID to view analytics graph (Enter for STU-2024-001): ");
        String sid = scanner.nextLine().trim();
        if (sid.isEmpty()) sid = "STU-2024-001";
        Student s = studentDAO.getStudentById(sid);
        String name = s != null ? s.getName() : sid;
        academicService.printExamComparisonGraph(sid, name);
    }

    // ==========================================
    // 🏛️ ADMIN PORTAL
    // ==========================================
    private static void adminPortalLogin() {
        System.out.print("\nEnter Admin Username (admin): ");
        String u = scanner.nextLine().trim();
        System.out.print("Enter Admin Password (admin123): ");
        String p = scanner.nextLine().trim();

        if (!"admin".equalsIgnoreCase(u) || !"admin123".equals(p)) {
            System.out.println(ConsoleTheme.ROSE + "✖ Invalid admin credentials." + ConsoleTheme.RESET);
            return;
        }

        while (true) {
            ConsoleTheme.printBanner("COLLEGE ADMINISTRATOR PORTAL");
            System.out.println("  " + ConsoleTheme.CYAN + "1." + ConsoleTheme.RESET
                    + " 👥 View All Enrolled Students & Account Balances");
            System.out.println("  " + ConsoleTheme.CYAN + "2." + ConsoleTheme.RESET + " ➕ Register New Student");
            System.out.println(
                    "  " + ConsoleTheme.CYAN + "3." + ConsoleTheme.RESET + " 🚨 Institutional Academic Risk Audit");
            System.out.println("  " + ConsoleTheme.CYAN + "4." + ConsoleTheme.RESET + " ↩ Logout to Main Menu");
            System.out.print(ConsoleTheme.BOLD + "\nEnter your choice (1-4): " + ConsoleTheme.RESET);

            String ch = scanner.nextLine().trim();
            if ("1".equals(ch)) {
                handleFacultyRoster();
            } else if ("2".equals(ch)) {
                System.out.print("Enter Student ID: ");
                String id = scanner.nextLine().trim();
                System.out.print("Enter Full Name: ");
                String name = scanner.nextLine().trim();
                System.out.print("Enter Email: ");
                String email = scanner.nextLine().trim();
                Student newStudent = new Student(id, name, email, Department.COMPUTER_SCIENCE, 100.0, 0.0);
                studentDAO.saveStudent(newStudent);
                System.out.println(ConsoleTheme.EMERALD + "✔ Student successfully registered and saved to database!"
                        + ConsoleTheme.RESET);
            } else if ("3".equals(ch)) {
                ConsoleTheme.printBanner("INSTITUTIONAL RISK AUDIT");
                for (Student s : studentDAO.getAllStudents()) {
                    String badge = s.getAttendancePercentage() < 75.0 ? ConsoleTheme.ROSE + "[CRITICAL ATTENDANCE]"
                            : ConsoleTheme.EMERALD + "[GOOD STANDING]";
                    System.out.printf("• %-14s %-20s Attendance: %5.1f%% %s\n" + ConsoleTheme.RESET,
                            s.getId(), s.getName(), s.getAttendancePercentage(), badge);
                }
            } else if ("4".equals(ch)) {
                break;
            }
        }
    }
}