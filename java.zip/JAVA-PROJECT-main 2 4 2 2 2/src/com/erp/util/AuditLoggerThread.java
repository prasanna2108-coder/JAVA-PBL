package com.erp.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

/**
 * Background Thread processing real-time system audit logging without blocking main application CLI.
 */
public class AuditLoggerThread implements Runnable {
    private final String action;
    private final String details;

    public AuditLoggerThread(String action, String details) {
        this.action = action;
        this.details = details;
    }

    @Override
    public void run() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data/system_audit.log", true))) {
            String logEntry = String.format("[%s] [THREAD: %s] ACTION: %s | DETAILS: %s",
                    LocalDateTime.now(), Thread.currentThread().getName(), action, details);
            writer.write(logEntry);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Audit Log Failed: " + e.getMessage());
        }
    }

    public static void logActionAsync(String action, String details) {
        // Creates and runs a separate concurrent execution thread
        Thread logThread = new Thread(new AuditLoggerThread(action, details), "AuditLogger-Thread");
        logThread.start();
    }
}