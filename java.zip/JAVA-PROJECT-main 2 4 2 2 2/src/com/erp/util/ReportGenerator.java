package com.erp.util;

import com.erp.model.GradeRecord;
import com.erp.model.Person;
import com.erp.model.Student;

public class ReportGenerator {

    /**
     * Java 21 Pattern Matching for switch & Record Pattern extraction.
     */
    public static String formatEntitySummary(Object obj) {
        return switch (obj) {
            case Student s -> 
                "[STUDENT REPORT] " + s.getName() + " | Dept: " + s.getDepartment() + " | Email: " + s.getEmail();
            case GradeRecord(String code, String name, double score) -> 
                "[GRADE RECORD] " + code + " - " + name + " -> Score: " + score;
            case Person p -> 
                "[PERSON REPORT] " + p.getName() + " (" + p.getEmail() + ")";
            case null -> "Invalid Object: Null reference provided.";
            default -> "Unknown Object Type: " + obj.getClass().getName();
        };
    }
}