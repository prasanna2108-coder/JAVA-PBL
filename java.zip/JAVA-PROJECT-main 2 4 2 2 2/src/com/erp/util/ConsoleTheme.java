package com.erp.util;

public class ConsoleTheme {
    // Basic ANSI Styles
    public static final String RESET = "\u001B[0m";
    public static final String BOLD = "\u001B[1m";
    public static final String DIM = "\u001B[2m";
    public static final String UNDERLINE = "\u001B[4m";

    // 256-Color Vibrant Cyber / Academic Palette (Matches Web UI)
    public static final String CYAN = "\u001B[38;5;51m";
    public static final String INDIGO = "\u001B[38;5;99m";
    public static final String EMERALD = "\u001B[38;5;48m";
    public static final String AMBER = "\u001B[38;5;220m";
    public static final String ROSE = "\u001B[38;5;198m";
    public static final String PURPLE = "\u001B[38;5;141m";
    public static final String BLUE = "\u001B[38;5;39m";
    public static final String WHITE = "\u001B[1;97m";
    public static final String GRAY = "\u001B[38;5;245m";
    public static final String DARK_GRAY = "\u001B[38;5;238m";

    // Backgrounds
    public static final String BG_OBSIDIAN = "\u001B[48;5;234m";
    public static final String BG_INDIGO = "\u001B[48;5;54m";
    public static final String BG_EMERALD = "\u001B[48;5;22m";
    public static final String BG_RED = "\u001B[48;5;52m";

    public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    public static void printHeader(String title, String subtitle) {
        int width = 78;
        String line = "═".repeat(width);
        System.out.println("\n" + INDIGO + "╔" + line + "╗" + RESET);
        printCenteredLine(BOLD + WHITE + "🏛️  " + title.toUpperCase() + "  🏛️" + RESET, width);
        if (subtitle != null && !subtitle.isBlank()) {
            printCenteredLine(CYAN + subtitle + RESET, width);
        }
        System.out.println(INDIGO + "╚" + line + "╝" + RESET);
    }

    public static void printBanner(String title) {
        int width = 78;
        String line = "─".repeat(width);
        System.out.println("\n" + CYAN + "┌" + line + "┐" + RESET);
        printCenteredLine(BOLD + WHITE + title + RESET, width);
        System.out.println(CYAN + "└" + line + "┘" + RESET);
    }

    private static void printCenteredLine(String text, int width) {
        String stripped = text.replaceAll("\u001B\\[[;?0-9]*[a-zA-Z]", "");
        int padding = Math.max(0, (width - stripped.length()) / 2);
        int extra = (width - stripped.length()) % 2;
        System.out.println(INDIGO + "║" + RESET + " ".repeat(padding) + text + " ".repeat(padding + extra) + INDIGO + "║" + RESET);
    }

    public static void printCard(String title, String content, String borderColor) {
        int width = 78;
        String line = "─".repeat(width);
        System.out.println(borderColor + "┌─ " + BOLD + WHITE + title + RESET + borderColor + " " + "─".repeat(Math.max(2, width - title.length() - 4)) + "┐" + RESET);
        for (String c : content.split("\n")) {
            String stripped = c.replaceAll("\u001B\\[[;?0-9]*[a-zA-Z]", "");
            int pad = Math.max(0, width - stripped.length());
            System.out.println(borderColor + "│ " + RESET + c + " ".repeat(Math.max(0, pad - 1)) + borderColor + "│" + RESET);
        }
        System.out.println(borderColor + "└" + line + "┘" + RESET);
    }

    public static String progressBar(double percentage, int barLength) {
        int filled = (int) Math.round((percentage / 100.0) * barLength);
        filled = Math.max(0, Math.min(barLength, filled));
        int empty = barLength - filled;
        String color = percentage >= 85 ? EMERALD : (percentage >= 70 ? AMBER : ROSE);
        return color + "█".repeat(filled) + DARK_GRAY + "░".repeat(empty) + RESET +
               String.format(" %s%5.1f%%%s", BOLD + color, percentage, RESET);
    }

    public static String statusBadge(String status) {
        if ("APPROVED".equalsIgnoreCase(status) || "CLEARED".equalsIgnoreCase(status) || "ISSUED".equalsIgnoreCase(status)) {
            return EMERALD + "[✔ " + status + "]" + RESET;
        } else if ("PENDING".equalsIgnoreCase(status)) {
            return AMBER + "[⏳ " + status + "]" + RESET;
        } else if ("REJECTED".equalsIgnoreCase(status) || "EXPIRED".equalsIgnoreCase(status)) {
            return ROSE + "[✖ " + status + "]" + RESET;
        }
        return WHITE + "[" + status + "]" + RESET;
    }
}
