package com.erp.util;

public class StringFormatter {

    /**
     * Uses StringBuilder for high-performance string concatenation.
     */
    public static String formatHeader(String title) {
        StringBuilder sb = new StringBuilder();
        sb.append("\n==================================================\n");
        sb.append("   ").append(title.toUpperCase()).append("\n");
        sb.append("==================================================");
        return sb.toString();
    }

    /**
     * Thread-safe text manipulation using StringBuffer.
     */
    public static String sanitizeInput(String rawInput) {
        if (rawInput == null) return "";
        StringBuffer sb = new StringBuffer(rawInput.trim());
        return sb.toString();
    }
}