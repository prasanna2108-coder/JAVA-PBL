package com.erp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static final String URL = "jdbc:h2:./data/student_erp_db;DB_CLOSE_DELAY=-1";
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    static {
        try {
            Class.forName("org.h2.Driver");
            initDatabase();
        } catch (ClassNotFoundException e) {
            System.err.println("⚠️ H2 JDBC Driver not found. Ensure h2 jar is added to classpath.");
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private static void initDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            // Main Students Table
            stmt.execute("CREATE TABLE IF NOT EXISTS students (" +
                    "id VARCHAR(50) PRIMARY KEY, " +
                    "name VARCHAR(100), " +
                    "email VARCHAR(100), " +
                    "department VARCHAR(50), " +
                    "attendance DOUBLE DEFAULT 100.0, " +
                    "fee_due DOUBLE DEFAULT 0.0)");

            // Auto-alter table to add missing columns for existing databases
            try { stmt.execute("ALTER TABLE students ADD COLUMN attendance DOUBLE DEFAULT 100.0"); } catch (SQLException ignored) {}
            try { stmt.execute("ALTER TABLE students ADD COLUMN fee_due DOUBLE DEFAULT 0.0"); } catch (SQLException ignored) {}

            // Grades Table
            stmt.execute("CREATE TABLE IF NOT EXISTS grades (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "student_id VARCHAR(50), " +
                    "course_code VARCHAR(50), " +
                    "course_name VARCHAR(100), " +
                    "score DOUBLE, " +
                    "FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE)");

            // Always ensure demo student accounts exist via MERGE
            stmt.execute("MERGE INTO students (id, name, email, department, attendance, fee_due) KEY(id) VALUES " +
                    "('STU-2024-001', 'Nithya Sree', 'student@college.edu', 'COMPUTER_SCIENCE', 88.5, 0.0), " +
                    "('STU-2024-002', 'Aditya Sharma', 'aditya@college.edu', 'COMPUTER_SCIENCE', 71.0, 1250.0), " +
                    "('STU-2024-003', 'Priya Raman', 'priya@college.edu', 'INFORMATION_TECHNOLOGY', 94.5, 0.0), " +
                    "('STU-2024-004', 'Kavya Senthil', 'kavya@college.edu', 'ELECTRONICS', 82.0, 0.0), " +
                    "('STU-2024-005', 'Rahul Verma', 'rahul@college.edu', 'MECHANICAL_ENGINEERING', 78.5, 450.0), " +
                    "('STU-2024-006', 'Divya Bharathi', 'divya@college.edu', 'COMPUTER_SCIENCE', 96.0, 0.0), " +
                    "('STU-2024-007', 'Karthik Rajan', 'karthik@college.edu', 'INFORMATION_TECHNOLOGY', 68.0, 3200.0), " +
                    "('STU-2024-008', 'Ananya Deshmukh', 'ananya@college.edu', 'CIVIL_ENGINEERING', 89.0, 0.0)");

            // Seed initial grades if empty
            try (var rsGrades = stmt.executeQuery("SELECT COUNT(*) FROM grades")) {
                if (rsGrades.next() && rsGrades.getInt(1) == 0) {
                    stmt.execute("INSERT INTO grades (student_id, course_code, course_name, score) VALUES " +
                            "('STU-2024-001', 'CS801', 'Distributed Systems', 90.0), " +
                            "('STU-2024-001', 'CS802', 'Cloud Computing & Virtualization', 83.0), " +
                            "('STU-2024-001', 'CS803', 'Deep Learning & Neural Networks', 93.0), " +
                            "('STU-2024-001', 'CS804', 'Cryptography & Network Security', 76.0), " +
                            "('STU-2024-001', 'CS805', 'Full-Stack Web Development', 88.0), " +
                            "('STU-2024-001', 'CS806', 'Big Data Analytics & Processing', 77.0), " +
                            "('STU-2024-001', 'CS807', 'Mobile Application Engineering', 84.0), " +
                            "('STU-2024-001', 'CS808', 'Capstone Project & Viva Voce', 97.0), " +
                            "('STU-2024-002', 'CS801', 'Distributed Systems', 63.0), " +
                            "('STU-2024-002', 'CS802', 'Cloud Computing & Virtualization', 69.0), " +
                            "('STU-2024-002', 'CS803', 'Deep Learning & Neural Networks', 72.0), " +
                            "('STU-2024-002', 'CS804', 'Cryptography & Network Security', 58.0), " +
                            "('STU-2024-003', 'IT801', 'Enterprise Cloud Architecture', 97.0), " +
                            "('STU-2024-003', 'IT802', 'Advanced Cyber Security & Forensics', 94.0), " +
                            "('STU-2024-003', 'IT803', 'Machine Learning & NLP Applications', 96.0), " +
                            "('STU-2024-004', 'EC801', 'VLSI Design & Verilog HDL', 84.0), " +
                            "('STU-2024-004', 'EC802', 'Embedded Systems & RTOS', 82.0), " +
                            "('STU-2024-005', 'ME801', 'Finite Element Analysis (FEA)', 78.0), " +
                            "('STU-2024-005', 'ME803', 'Robotics & Industrial Automation', 87.0)");
                }
            } catch (SQLException ignored) {}

            System.out.println("🗄️ Database Tables Initialized & Seeded Successfully (JDBC Ready).");
        } catch (SQLException e) {
            System.err.println("⚠️ Database initialization error: " + e.getMessage());
        }
    }
}