package com.erp.dao;

import com.erp.model.GradeRecord;
import com.erp.model.Student;

import java.util.List;

public interface StudentDAO {
    void saveStudent(Student student);
    void addGrade(String studentId, GradeRecord grade);
    Student getStudentById(String id);
    List<Student> getAllStudents();
    boolean deleteStudent(String id);
}