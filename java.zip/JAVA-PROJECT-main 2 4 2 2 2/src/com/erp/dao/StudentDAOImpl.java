package com.erp.dao;

import com.erp.model.Department;
import com.erp.model.GradeRecord;
import com.erp.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class StudentDAOImpl implements StudentDAO {

    @Override
    public void saveStudent(Student student) {
        String sql = "MERGE INTO students (id, name, email, department, attendance, fee_due) KEY(id) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, student.getId());
            stmt.setString(2, student.getName());
            stmt.setString(3, student.getEmail());
            stmt.setString(4, student.getDepartment().name());
            stmt.setDouble(5, student.getAttendancePercentage());
            stmt.setDouble(6, student.getFeeDueAmount());

            stmt.executeUpdate();
            System.out.println("💾 Student saved to JDBC Database.");
        } catch (SQLException e) {
            System.err.println("⚠️ JDBC Error (saveStudent): " + e.getMessage());
        }
    }

    @Override
    public void addGrade(String studentId, GradeRecord grade) {
        String sql = "INSERT INTO grades (student_id, course_code, course_name, score) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, studentId);
            stmt.setString(2, grade.courseCode());
            stmt.setString(3, grade.courseName());
            stmt.setDouble(4, grade.score());

            stmt.executeUpdate();
            System.out.println("💾 Grade added via JDBC PreparedStatement.");
        } catch (SQLException e) {
            System.err.println("⚠️ JDBC Error (addGrade): " + e.getMessage());
        }
    }

    @Override
    public Student getStudentById(String id) {
        String studentSql = "SELECT * FROM students WHERE UPPER(id) = UPPER(?) OR UPPER(email) = UPPER(?)";
        String gradesSql = "SELECT * FROM grades WHERE student_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(studentSql)) {

            stmt.setString(1, id);
            stmt.setString(2, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String fetchedId = rs.getString("id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                Department dept = Department.COMPUTER_SCIENCE;
                try {
                    dept = Department.valueOf(rs.getString("department"));
                } catch (Exception ignored) {}

                double attendance = 100.0;
                double feeDue = 0.0;

                try {
                    attendance = rs.getDouble("attendance");
                } catch (SQLException ignored) {}

                try {
                    feeDue = rs.getDouble("fee_due");
                } catch (SQLException ignored) {}

                Student student = new Student(fetchedId, name, email, dept, attendance, feeDue);

                // Fetch grades associated with this student
                try (PreparedStatement gradeStmt = conn.prepareStatement(gradesSql)) {
                    gradeStmt.setString(1, fetchedId);
                    ResultSet grs = gradeStmt.executeQuery();
                    while (grs.next()) {
                        student.getGrades().add(new GradeRecord(
                                grs.getString("course_code"),
                                grs.getString("course_name"),
                                grs.getDouble("score")
                        ));
                    }
                }
                return student;
            }
        } catch (SQLException e) {
            System.err.println("⚠️ JDBC Error (getStudentById): " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT id FROM students";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Student s = getStudentById(rs.getString("id"));
                if (s != null) {
                    students.add(s);
                }
            }
        } catch (SQLException e) {
            System.err.println("⚠️ JDBC Error (getAllStudents): " + e.getMessage());
        }

        // Sort students by ID
        students.sort(Comparator.comparing(Student::getId));
        return students;
    }

    @Override
    public boolean deleteStudent(String id) {
        String sql = "DELETE FROM students WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, id);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("⚠️ JDBC Error (deleteStudent): " + e.getMessage());
            return false;
        }
    }
}