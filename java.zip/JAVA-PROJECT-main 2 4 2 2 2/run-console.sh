#!/usr/bin/env bash
# Quick runner script for the Java Console ERP Application
cd "$(dirname "$0")"

# Ensure bin directory exists and code is compiled
mkdir -p bin
javac -cp "lib/h2.jar:src" -d bin $(find src -name "*.java")

# Launch the interactive terminal console ERP
java -cp "lib/h2.jar:bin" com.erp.main.MainApp
